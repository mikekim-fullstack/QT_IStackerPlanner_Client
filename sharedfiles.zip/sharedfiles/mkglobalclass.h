#include <inttypes.h>
#include <iostream>
#include <stdarg.h>
#include <math.h>
#include <stdlib.h>
//#include "../sharedfiles/mkZoeRobotics_globalDataStruct.h"
#ifndef MKGLOBALCLASS_H
#define MKGLOBALCLASS_H
#define TICK_PRESCALE 128.0
#define  TICK_FREQ_SQRT_ERROR_COM  84000000UL/TICK_PRESCALE*0.676
#define  DIST2STEP_20T2MM 40 // (20TH*2MM=40MM/REV) MM TO STPEPS

#define  Z_DIST_PER_REV 100 //5 //  5mm/rev (Ball Screw Lead pitch)
#define  Z_MICROSTEPPING 1600//3200 //400 // Default MICROSTEP
#define  MAX_Z_TRAVEL_DIST 1000.0 //[mm]

#define  X_DIST_PER_REV 100 //  100mm/rev (=20TH*5MM)
#define  X_MICROSTEPPING 1600//3200 //1600 (= 200 STEPS X 8 MICROSTEP)
#define  MAX_X_TRAVEL_DIST 1650.0 //[mm]

#define ENCODER_CONVERSION 0.087890625 // == 1/4096.0*360.0

#define MAX_MOTIONDATA_SIZE 5500
//#define  R1_GEAR_RATIO  6
//#define  R1_ANGLE_PER_REV 60 //  60 angle/rev = OUTPUT/INPUT(MOTOR 1REV) = (360/R1_GEAR_RATIO)/rev )
//#define  R1_MICROSTEPPING 1600 //1600 (= 200 STEPS X 8 MICROSTEP)
//#define  MAX_R1_TRAVEL_ANGLE 315 //[mm]


//#define  R2_GEAR_RATIO  3
//#define  R2_ANGLE_PER_REV 120 // 120 angle/rev = OUTPUT/INPUT(MOTOR 1REV) = (360/R2_GEAR_RATIO)/rev )
//#define  R2_MICROSTEPPING 1600 //1600 (= 200 STEPS X 8 MICROSTEP/REV)
//#define  MAX_R2_TRAVEL_ANGLE 303 //[mm]




// OPERATION MODE
enum ACTION_MODE {SINGLE_JNT_MODE=10,
                  MULTI_ALL_JNT_MODE=20,
                  MULTI_XZ_JNT_MODE,
                  MULTI_ARM_JNT_MODE,
                  CARTESIAN_MODE=30,
                  CIRCLE_MODE=40};
enum OP_MODE {STOPPED=1,
              JOB_DONE,
              ASK_MOVE,
              MOVING,
              SET_SPEED,
              GEN_EEMOTION,
              GEN_CIRCLE,
              GEN_SPIRAL,
              ASK_HOME,
              HOMING,
              BUSY };
enum RESP_CMD {RC_ACK=50,
               RC_STATUS,
               RC_STATUS_ALL_POS,
               RC_STATUS_LINEAR,
               RC_STATUS_EEROTATION,
               RC_STATUS_CIRCLE,
               RC_STATUS_SPRIAL,
               RC_UPDATE_MOTION,
               RC_STATUS_JOB_DONE,
               RC_ACK_STOP,
               RC_ENCODER_VALUE,
               RC_ORDER_DONE};
enum SEND_CMD {
                SC_MOVE  =0 ,
                SC_SET_SPEED,
                SC_GEN_EELINEAR,
                SC_GEN_EEROTATION,
                SC_GEN_CIRCLE,
                SC_GEN_SPIRAL,
                SC_HOMING=10,
                SC_STATUS,
                SC_STATUS_ALL_POS,
                SC_UPDATE_MOTION,
                SC_SAVE_POS,
                SC_SET_ZERO_ENCODER,
                SC_GET_ENCODER,
                SC_SETPOS=20,
                SC_ORDER=30,
                SC_DROP_CUP,
                SC_STOP=40,
                SC_PAUSE,
                SC_RESUME,
                SC_ASK_MOVE = 50,
                SC_ASK_CIRCLE,
                SC_ASK_HOMING,
                SC_TIME_DELAY = 60,
                SC_TIME_DELAY_MC,
                SC_REBOOT=100,
                SC_POWER,
                SC_Z_BRAKE,
                SC_CANCEL_JOB=999,
              };
enum OP_ERROR {
    // ...ERROR 100s: input command corruption errors...
      ERROR = 100,
      ERROR_MISSING_M = 150,
      //..........................

      ERROR_JOINT_LIMIT = 200,

      ERROR_SET_SPEED = 300,
      ERROR_SET_SPEED_TOO_SLOW,
      ERROR_SET_SPEED_TOO_FAST,
      ERROR_SET_SPEED_TOO_FAST_CN,
      ERROR_MOVE_TOO_SMALL,

      ERROR_SET_LINEAR = 400,
      ERROR_SET_CIRCLE = 500,
      ERROR_SET_SPIRAL = 600,
      ERROR_READ_ENCORDER = 700,
      ERROR_SERIAL_TIMEOUT = 800,

      ERROR_IK_NO_SOLUTION = 1000,
      ERROR_IK_NO_SOLUTION_INITAL,
      ERROR_IK_NO_SOLUTION_IN_LOOP,

      ERROR_CHECKSUM = 1100,
      ERROR_SIZE = 1200
//    ERROR=100,
//               ERROR_MOVE_TOO_SMALL,
//               ERROR_JOINT_LIMIT=200,
//               ERROR_SET_SPEED=300,
//               ERROR_SET_SPEED_TOO_SLOW,
//               ERROR_SET_SPEED_TOO_FAST,
//               ERROR_SET_SPEED_TOO_FAST_CN,
//               ERROR_SET_LINEAR=400,
//               ERROR_SET_CIRCLE=500,
//               ERROR_SET_SPIRAL=600,
//               ERROR_READ_ENCORDER=700,
//               ERROR_SERIAL_TIMEOUT=800,
//               ERROR_MISSING_M=900,
//               ERROR_IK_NO_SOLUTION=1000,
//               ERROR_IK_NO_SOLUTION_INITAL,
//               ERROR_IK_NO_SOLUTION_IN_LOOP,
//               ERROR_CHECKSUM=1100,
//               ERROR_SIZE=1200
};
enum SELECT_MOTOR { SM_X,
                    SM_R1,
                    SM_R2,
                    SM_Z,
                    SM_KIN,
                    SM_KIN_Z};
enum JOINT_TYPE { JT_LIN=0, JT_ROT};

using namespace std;
/////////////////////////////////////////////////////////////
///
///
enum SEL_MODE
{
  MODE_JOINT = 0,
  MODE_CARTESIAN
};
///
//////////////////////////////////////////////////////////////

typedef struct
{
  // ...OUTPUT...
  int steps;   // total steps(pluse)
  int Na;      // pulse counts for acceleration area
  int Nac;     // pulse counts for acceleration and constant areas
  int NNb;     // pulse counts for deceleration area
  int Cn_acc0; // fisrt period time for 1st pulse of acceleration on Timer.
  int8_t dir;       // step motor direction 1:CCW, -1:CC
} SPEEDProfile;     // 28bytes

typedef struct
{
  double EEx[2]; //[START, END]
  double EEy[2]; //[START, END]
  double posZ = 0;         // initial position of Z[mm]
  double heightZ = 0;      // How much the EE move along with Z axis.[mm]
  double EETheta;//[rad]
  double Vel;
} LINEARProfile; // 28bytes
typedef struct
{
  double EEx;
  double EEy;
  double EETheta[2]; //[START, END][rad]
  double Vel;
} EEROTATIONProfile; // 28bytes
typedef struct
{
    double speed;            // speed of the center of Cup holder(EE)[deg/sec]
    double radius;           // radius for circle to make.[mm]
    double cenPosX, cenPosY; // initial position of the center of Cup holder(EE) [mm]
    double EETheta;          // initial angle of EE [deg]
    double arcAng;           // How much the EE rotate [deg]
} CIRCLEProfile; // 28bytes
typedef struct
{
  double speed;            // speed of the center of Cup holder(EE)[deg/sec]
  double radius;           // radius for circle to make.[mm]
  double cenPosX, cenPosY; // initial position of the center of Cup holder(EE) [mm]
  double EETheta;          // initial angle of EE [deg]
  double arcAng;           // How much the EE rotate [deg]
  double posZ = 0;         // initial position of Z[mm]
  double heightZ = 0;      // How much the EE move along with Z axis.[mm]
} SPIRALProfile; // 28bytes
// ... storing I.K motion for timer
typedef struct _KIN_PARAM_
{
  double x, y;  // x, y position of End-Effector
  double theta; // tip angle of End-Effector

  double t1, t2; // joing angle
  double L;      // x position of robot
} KIN_PARAM;

typedef struct {
    uint8_t select;
    float vel;
    float radius;
    float cenPos[2];
    float EndEffectorAng;
    int arcAng;
}circleProfile;

typedef struct _speedRampData
{
  volatile bool activated = false;
  volatile bool pulseTick = false;
  volatile bool pulseDown = false;
  float rest = 0;
  float Ta = 0, Tb = 0, Tc = 0, Ttotal = 0;
  int Na = 0;             // Step count for acceleration Zone
  int Nb = 0;             // Step count for deceleration Zone
  int Nc = 0;             // Step count for conatant speed Zone
  int Nac = 0;            // Nac=Na+Nc
  int NNb = 0;            // Same as Nb for deceleration
  int Cn_const_speed = 0; // time delay(OCR1A) for constant speed zone
  int Cn_acc0 = 0;        // time delay at the starting acceleration.
  int Cn_dec0;            // time delay at the starting deceleration.

  volatile int Cn = 0;         // time delay by N step
  volatile int totalSteps = 0; // total steps
  volatile int step_count = 0;
  volatile float C = 0;

  //! What part of the speed ramp we are in.
  unsigned char run_state;
  //! Direction stepper motor should move.
  volatile int8_t dir = 0;     // 1:CCW, -1:CW
  volatile int8_t prevDir = 0; // 1:CCW, -1:CW

  int elapsedTime = 0;

  void reset()
  {
    activated = false;
    // pulseTick=false;
    // pulseDown=false;
    rest = 0;
    Ta = 0, Tb = 0, Tc = 0, Ttotal = 0;
    Na = 0;             // Step count for acceleration Zone
    Nb = 0;             // Step count for deceleration Zone
    Nc = 0;             // Step count for conatant speed Zone
    Nac = 0;            // Nac=Na+Nc
    NNb = 0;            // Same as Nb for deceleration
    Cn_const_speed = 0; // time delay(OCR1A) for constant speed zone
    Cn_acc0 = 0;        // time delay at the starting acceleration.
    Cn_dec0;            // time delay at the starting deceleration.

    Cn = 0;         // time delay by N step
    totalSteps = 0; // total steps
    step_count = 0;
    C = 0;
  }
} SPEEDRampData;


typedef struct _KINEMATICS_DATA_
{
  typedef struct
  {
    int Cn = 0;    // pluse frequency (one counter time)
    int steps = 0; // how many pulse should be counted
    int dir = 0;   // stepper motor direction(1: CCW, -1:CW)
  } MOTIONDATA;

  volatile MOTIONDATA motionData[MAX_MOTIONDATA_SIZE] = {};
  volatile int indexMotionData = 0;
  volatile bool activated = false;
  volatile bool pulseTick = false;
  volatile bool pulseDown = false;
  volatile int step_count = 0;
  volatile int step_sum = 0;
  volatile int8_t prevDir = 0;

  int dataSize = 0;
  // int32_t finalSumSteps = 0;
  int32_t totalSteps = 0;
  int elapsedTime = 0;
  int inline getMotionCn()
  {
    return motionData[indexMotionData].Cn;
  }
  int inline getMotionSteps()
  {
    return motionData[indexMotionData].steps;
  }
  int8_t inline getMotionDir()
  {
    return motionData[indexMotionData].dir;
  }
  int inline nextMotionData()
  {
    return ++indexMotionData;
  }
  bool inline isMotionDone()
  {
    if (step_sum == totalSteps - 1)
      return true;
    return false;
  }
  void inline motionDone()
  {
    indexMotionData = 0;
    activated = false;
    // pulseTick=false;
    // pulseDown=false;
    step_count = 0;
  }
  void reset()
  {
    indexMotionData = 0;
    activated = false;
    pulseTick = false;
    pulseDown = false;
    step_count = 0;
    memset((MOTIONDATA *)motionData, 0, sizeof(MOTIONDATA) * MAX_MOTIONDATA_SIZE);
    dataSize = 0;
    totalSteps = 0;
  }
} KIN_DATA;


typedef struct
{
  // int jobID=0;
  int CMDCode = 0;
  volatile int32_t abs_step_pos = 0; // Step counts
  volatile float abs_mm_pos = 0;     // milimeters
  volatile int16_t OperationMode = STOPPED;

public:
  void reset()
  {
    CMDCode = 0;
    // jobID=0;
    OP_MODE OperationMode = STOPPED;
  }
} POSData;

///////////////////////////////////////////////////
typedef struct TARGETDEST{
    int jobID=-1; // selection of motor
    int axisID;
    double distance=0;// [mm]
    double vel=0;// [rad/sec]
    double accel=0;// [rad/sec^2]
    double decel=0;// [rad/sec^2]
    // bool seen=false;
} targetDest;



//////////////////////////////////////////////////////////////
class PacketBase
{
protected:

    char packet[128];
    char packetName[56]={'\0'};
    // double scale = 1.0;//100.0;

    bool seen=true;
    char *strchr_pointer=0;

    bool codeSeen(char code) {
        //char *strchr(const char *str, int c) searches for the first occurrence of the character c (an unsigned char) in the string pointed to by the argument str
        strchr_pointer = strchr(packet, code);
        return (strchr_pointer != nullptr);
    }
    double codeValue() {
        //double strtod(const char *str, char **endptr) converts the string pointed to by the argument str to a floating-point number (type double). If endptr is not NULL, a pointer to the character after the last character used in the conversion is stored in the location referenced by endptr.
        return (strtod(&packet[strchr_pointer - packet + 1], nullptr));
    }
public:
    uint16_t cmdCode;
    uint16_t jobID=0;
    uint16_t nSequence=0;
    PacketBase() {
        memset(packet,0,sizeof(char)*128);
    }
    ~PacketBase() {

    }
    PacketBase(PacketBase &other) {
        memcpy(packet, other.packet, sizeof(char)*128);
        jobID = other.jobID;
        nSequence = other.nSequence;
        seen = other.seen;
        strchr_pointer = other.strchr_pointer;
    }
    PacketBase & operator = (PacketBase & other) {
        if(this==&other) return *this;
        memcpy(packet, other.packet, sizeof(char)*128);
        jobID = other.jobID;
        nSequence = other.nSequence;
        seen = other.seen;
        strchr_pointer = other.strchr_pointer;

        return *this;
    }


    char* packf(char const *fmt, ...) {
        memset(packet,0,sizeof(char)*128);
        va_list args;
        va_start(args, fmt);
        vsprintf(packet,fmt, args);
        //cout<<"len: "<<strlen(packet)<<endl<<flush;
        packet[strlen(packet)]='\0';
        va_end(args);
        return packet;
    }
    char *get() {
        return packet;
    }
    int length() {
        if(seen) return strlen(packet);
        return 0;
    }
    int getCode() {
        return cmdCode;
    }
    int getJobID() {
        return jobID;
    }
    int getNumSequence() {
        return nSequence;
    }
    void print() {

        // ...temporary disable printing...
        std::cout<<"\033[1;36m  Packet["<<packetName <<"] = \033[0m"<<packet<<std::endl<<std::flush;
    }
};
////////////////////////////////////////////////////
///////////////////////////////////////////////////
class PacketAckRec: public PacketBase
{
public:
    uint16_t reponseCode=0;
    uint8_t axisID=0;
    uint16_t errorCode=0;

public:
    PacketAckRec() {
        strcpy(packetName,"PacketAckRec");
    }
    //    char *pack() {
    //        sprintf(packet, "C%d J%d\n", cmdCode, jobID);
    //        return packet;
    //    }
    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('M')) axisID=(uint8_t) codeValue();
        else seen=false;
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;
        if(codeSeen('E')) errorCode=(uint16_t)codeValue();
        else seen=false;
        return seen;
    }
};
///////////////////////////////////////////////////
class PacketStatusRec: public PacketBase
{
public:
    uint16_t reponseCode=0;
    uint8_t axisID=0;
    int32_t absSteps=0;
    uint16_t opMode=0;
    int8_t statusHoming=0;
    int8_t switchHome=-1;
    uint32_t elapsedTime=0;

public:
    PacketStatusRec() {
        cmdCode=SC_STATUS;
        strcpy(packetName,"PacketStatusRec");
    }

    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('M')) axisID=(uint8_t) codeValue();
        else seen=false;
        if(codeSeen('P')) absSteps=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('O')) opMode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('S')) statusHoming=(int8_t) codeValue();
        else seen=false;
        if(codeSeen('H')) switchHome=(int8_t) codeValue();
        else seen=false;
        if(codeSeen('T')) elapsedTime=(uint32_t) codeValue();
        else seen=false;
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;
        return seen;
    }
};
///////////////////////////////////////////////////
class PacketAllPosRec: public PacketBase
{
public:
    uint16_t reponseCode=0;
    int32_t absSteps[4]={0};
    PacketAllPosRec() {
        cmdCode=SC_STATUS_ALL_POS;
        strcpy(packetName,"PacketAllPosRec");
    }

    //    char *pack() {
    //        sprintf(packet, "A%d B%d C%d D%d J%d\n",
    //                absSteps[0], absSteps[1],absSteps[2],absSteps[3],jobID);
    //        return packet;
    //    }
    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('A')) absSteps[0]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('B')) absSteps[1]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('C')) absSteps[2]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('D')) absSteps[3]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;
        return seen;
    }
};
///////////////////////////////////////////////////
class PacketAckStopRec: public PacketBase
{
public:
    uint16_t reponseCode=0;
    int32_t absSteps[4]={0};
    PacketAckStopRec() {
        cmdCode=SC_STOP;
        strcpy(packetName,"PacketAckStopRec");
    }

    //    char *pack() {
    //        sprintf(packet, "A%d B%d C%d D%d J%d\n",
    //                absSteps[0], absSteps[1],absSteps[2],absSteps[3],jobID);
    //        return packet;
    //    }
    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('A')) absSteps[0]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('B')) absSteps[1]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('C')) absSteps[2]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('D')) absSteps[3]=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;
        return seen;
    }
};
///////////////////////////////////////////////////
class PacketEncoderRec: public PacketBase
{
public:
    uint16_t reponseCode=0;
    int axisID=0;
    double encoderValue=0;

public:
    PacketEncoderRec() {
        cmdCode=SC_GET_ENCODER;
        strcpy(packetName,"PacketEncoderRec");
    }

    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('M')) axisID=(int) codeValue();
        else seen=false;
        if(codeSeen('P')) encoderValue=(codeValue())*ENCODER_CONVERSION;
        else seen=false;
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;
        return seen;
    }
};
///////////////////////////////////////////////////
class PacketCircleRec: public PacketBase
{
public:
    uint16_t reponseCode=0;
    uint16_t errorCode=0;
    uint16_t dataSize[3]={0};
    uint32_t absSteps[3]={0};

public:
    PacketCircleRec() {
        cmdCode=SC_GEN_CIRCLE;
        strcpy(packetName,"PacketCircleRec");
    }
    //    int R=SC_GEN_CIRCLE;
    char *pack() {
        sprintf(packet, "R%d G%d A%d B%d C%d D%d E%d F%d H%d J%d N%d\n",
                reponseCode, cmdCode, dataSize[0], absSteps[0],dataSize[1],absSteps[1], dataSize[2],absSteps[2],errorCode, jobID, nSequence);
        return packet;
    }
    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;

        if(codeSeen('A')) dataSize[0]=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('B')) absSteps[0]=(uint32_t) codeValue();
        else seen=false;

        if(codeSeen('C')) dataSize[1]=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('D')) absSteps[1]=(uint32_t) codeValue();
        else seen=false;

        if(codeSeen('E')) dataSize[2]=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('F')) absSteps[2]=(uint32_t) codeValue();
        else seen=false;

        if(codeSeen('H')) errorCode=(uint16_t) codeValue();
        else seen=false;

        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;

        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;

        pack();
        return seen;
    }
};
///////////////////////////////////////////////////
class PacketSpiralRec: public PacketBase
{
public:
    uint16_t reponseCode=0;
    uint16_t errorCode=0;
    uint16_t dataSize[3]={0};
    uint32_t absSteps[3]={0};

public:
    PacketSpiralRec() {
        cmdCode=SC_GEN_SPIRAL;
        strcpy(packetName,"PacketSpiralRec");
    }
    //    int R=SC_GEN_CIRCLE;
    char *pack() {
        sprintf(packet, "R%d G%d A%d B%d C%d D%d E%d F%d H%d J%d N%d\n",
                reponseCode, cmdCode, dataSize[0], absSteps[0],dataSize[1],absSteps[1], dataSize[2],absSteps[2],errorCode, jobID, nSequence);
        return packet;
    }
    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;

        if(codeSeen('A')) dataSize[0]=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('B')) absSteps[0]=(uint32_t) codeValue();
        else seen=false;

        if(codeSeen('C')) dataSize[1]=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('D')) absSteps[1]=(uint32_t) codeValue();
        else seen=false;

        if(codeSeen('E')) dataSize[2]=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('F')) absSteps[2]=(uint32_t) codeValue();
        else seen=false;

        if(codeSeen('H')) errorCode=(uint16_t) codeValue();
        else seen=false;

        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;

        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;

        pack();
        return seen;
    }
};
    /////////////////////////////////////////////////
    class PacketLinearRec: public PacketBase
    {
    public:
        uint16_t reponseCode=0;
        uint16_t errorCode=0;
        uint16_t dataSize[3]={0};
        uint32_t absSteps[3]={0};

    public:
        PacketLinearRec() {
            cmdCode=SC_GEN_EELINEAR;
            strcpy(packetName,"PacketLinearRec");
        }
        //    int R=SC_GEN_CIRCLE;
        char *pack() {
            sprintf(packet, "R%d G%d A%d B%d C%d D%d E%d F%d H%d J%d N%d\n",
                    reponseCode, cmdCode, dataSize[0], absSteps[0],dataSize[1],absSteps[1], dataSize[2],absSteps[2],errorCode, jobID, nSequence);
            return packet;
        }
        bool unpack(char *cmdStr) {
            seen=true;
            strcpy(packet,cmdStr);

            if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
            else seen=false;

            if(codeSeen('A')) dataSize[0]=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('B')) absSteps[0]=(uint32_t) codeValue();
            else seen=false;

            if(codeSeen('C')) dataSize[1]=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('D')) absSteps[1]=(uint32_t) codeValue();
            else seen=false;

            if(codeSeen('E')) dataSize[2]=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('F')) absSteps[2]=(uint32_t) codeValue();
            else seen=false;

            if(codeSeen('H')) errorCode=(uint16_t) codeValue();
            else seen=false;

            if(codeSeen('J')) jobID=(uint16_t)codeValue();
            else seen=false;

            if(codeSeen('N')) nSequence=(uint16_t)codeValue();
            else seen=false;
            pack();
    //        if(codeSeen('N')) nSequence=(uint8_t)codeValue();
    //        else seen=false;
            return seen;
        }
    };
    /////////////////////////////////////////////////
    /////////////////////////////////////////////////
    class PacketEERotateRec: public PacketBase
    {
    public:
        uint16_t reponseCode=0;
        uint16_t errorCode=0;
        uint16_t dataSize[3]={0};
        uint32_t absSteps[3]={0};

    public:
        PacketEERotateRec() {
            cmdCode=SC_GEN_EEROTATION;
            strcpy(packetName,"PacketEERotateRec");
        }
        char *pack() {
            sprintf(packet, "R%d G%d A%d B%d C%d D%d E%d F%d H%d J%d N%d\n",
                    reponseCode, cmdCode, dataSize[0], absSteps[0],dataSize[1],absSteps[1], dataSize[2],absSteps[2],errorCode, jobID, nSequence);
            return packet;
        }
        bool unpack(char *cmdStr) {
            seen=true;
            strcpy(packet,cmdStr);

            if(codeSeen('R')) reponseCode=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
            else seen=false;

            if(codeSeen('A')) dataSize[0]=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('B')) absSteps[0]=(uint32_t) codeValue();
            else seen=false;

            if(codeSeen('C')) dataSize[1]=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('D')) absSteps[1]=(uint32_t) codeValue();
            else seen=false;

            if(codeSeen('E')) dataSize[2]=(uint16_t) codeValue();
            else seen=false;
            if(codeSeen('F')) absSteps[2]=(uint32_t) codeValue();
            else seen=false;

            if(codeSeen('H')) errorCode=(uint16_t) codeValue();
            else seen=false;

            if(codeSeen('J')) jobID=(uint16_t)codeValue();
            else seen=false;

            if(codeSeen('N')) nSequence=(uint16_t)codeValue();
            else seen=false;

            pack();
            return seen;
        }
    };
    /////////////////////////////////////////////////
///////////////////////////////////////////////////
class PacketSpeedProfile: public PacketBase
{
public:
    uint8_t axisID;
    uint32_t steps;   // total steps(pluse)
    uint32_t Na;      // pulse counts for acceleration area
    uint32_t Nac;     // pulse counts for acceleration and constant areas
    uint32_t NNb;     // pulse counts for deceleration area
    uint32_t Cn_acc0; // fisrt period time for 1st pulse of acceleration on Timer.
    uint32_t Cn_dec0; // fisrt period time for 1st pulse of deceleration on Timer.
    int8_t dir;       // step motor direction 1:CCW, 0:CC
    float rest;      // save  decimal points on first step.
public:
    PacketSpeedProfile() {
         cmdCode=SC_SET_SPEED;
         strcpy(packetName,"PacketSpeedProfile");
    }

    char* pack() {
        sprintf(packet, "G%dM%dS%dA%dC%dD%dT%dV%1.3fO%dJ%dN%d", cmdCode, axisID, steps, Na, Nac, NNb, Cn_acc0, rest, dir, jobID, nSequence);
        return packet;
    }
    bool unpack(char *cmdStr) {
        seen=true;
        strcpy(packet,cmdStr);

        if(codeSeen('G')) cmdCode=(uint16_t) codeValue();
        else seen=false;
        if(codeSeen('M')) axisID=(uint8_t) codeValue();
        else seen=false;
        if(codeSeen('S')) steps=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('A')) Na=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('C')) Nac=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('D')) NNb=(int32_t) codeValue();
        else seen=false;
        if(codeSeen('T')) Cn_acc0=(uint32_t) codeValue();
        else seen=false;
//        if(codeSeen('U')) Cn_dec0=(uint32_t) codeValue();
//        else seen=false;
        if(codeSeen('V')) rest=(float) codeValue();
        else seen=false;
        if(codeSeen('O')) dir=(int8_t) codeValue();
        else seen=false;
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        else seen=false;
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
        else seen=false;
        return seen;
    }


};

///////////////////////////////////////////////////
class PacketSpeed: public PacketBase
{
public:
    uint8_t axisID;
    double diffPos=0;
    double vel=0;
    double accel=0;
public:
    PacketSpeed () {
        cmdCode = SC_SET_SPEED;
        strcpy(packetName,"PacketSpeed");
    }
    char* pack() {
        sprintf(packet,"G%dM%dD%5.3fV%5.3fA%5.3fJ%dN%d",
                cmdCode, axisID,diffPos,vel, accel,jobID, nSequence);
        return packet;
    }
    void unpack(char *cmdStr) {
        strcpy(packet,cmdStr);
        if(codeSeen('G')) cmdCode=(uint16_t)codeValue();
        if(codeSeen('M')) axisID=(uint8_t)codeValue();
        if(codeSeen('D')) diffPos=codeValue();
        if(codeSeen('V')) vel=codeValue();
        if(codeSeen('A')) accel=codeValue();
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
    }
} ;
///////////////////////////////////////////////////
class PacketCircle: public PacketBase
{
public:
    double speed=0;
    double radius=0;
    double cenPosX=0, cenPosY=0;
    double EETheta=0;
    double arcAng=0;
    //uint8_t numRepeat=1;

public:
    PacketCircle(){
        cmdCode = SC_GEN_CIRCLE;
        strcpy(packetName,"PacketCircle");
    }
    char* pack() {
        sprintf(packet, "G%dS%3.3fR%3.3fX%3.3fY%3.3fT%3.3fA%3.3fJ%dN%d",
                cmdCode,speed,radius,cenPosX,cenPosY,EETheta, arcAng,jobID, nSequence);
        return packet;
    }
    void unpack(char *cmdStr) {
        strcpy(packet,cmdStr);
        if(codeSeen('G')) cmdCode=(uint8_t)codeValue();
        if(codeSeen('S')) speed=codeValue();
        if(codeSeen('R')) radius=codeValue();
        if(codeSeen('X')) cenPosX=codeValue();
        if(codeSeen('Y')) cenPosY=codeValue();
        if(codeSeen('T')) EETheta=codeValue();
        if(codeSeen('A')) arcAng=codeValue();
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
    }
};
///////////////////////////////////////////////////
class PacketSpiral: public PacketBase
{
public:
    double speed=0;
    double radius=0;
    double cenPosX=0, cenPosY=0;
    double EETheta=0;
    double arcAng=0;
    double posZ=0;
    double heightZ=0;

public:
    PacketSpiral(){
        cmdCode = SC_GEN_SPIRAL;
        strcpy(packetName,"PacketSpiral");
    }
    char* pack() {
        sprintf(packet, "G%dS%3.3fR%3.3fX%3.3fY%3.3fT%3.3fA%3.3fB%3.3fC%3.3fJ%dN%d",
                cmdCode,speed,radius,cenPosX,cenPosY,EETheta, arcAng, posZ, heightZ, jobID, nSequence);
        return packet;
    }
    void unpack(char *cmdStr) {
        strcpy(packet,cmdStr);
        if(codeSeen('G')) cmdCode=(uint8_t)codeValue();
        if(codeSeen('S')) speed=codeValue();
        if(codeSeen('R')) radius=codeValue();
        if(codeSeen('X')) cenPosX=codeValue();
        if(codeSeen('Y')) cenPosY=codeValue();
        if(codeSeen('T')) EETheta=codeValue();
        if(codeSeen('A')) arcAng=codeValue();
        if(codeSeen('B')) posZ=codeValue();
        if(codeSeen('C')) heightZ=codeValue();
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
    }
};
///////////////////////////////////////////////////
class EEMovePacket: public PacketBase
{
    public:
    double XeeStart=0;
    double XeeEnd=0;
    double YeeStart=0;
    double YeeEnd=0;
    double ZeeStart=0;
    double ZeeEnd=0;
    double THee=0;
    double Vel=0;



    EEMovePacket() {
        cmdCode = SC_GEN_EELINEAR;
        strcpy(packetName,"EEMovePacket");
    }

    char* pack() {
        sprintf(packet,"G%dX%5.3fY%5.3fZ%5.3fT%5.3fV%5.3fA%5.3fB%5.3fC%5.3fJ%dN%d",
//                sprintf(packet,"G%d X%5.1f Y%5.1f Z%5.1f T%5.1f V%5.1f A%5.1f B%5.1f C%5.1f J%d N%d\n",
                cmdCode, XeeStart, XeeEnd, YeeStart, YeeEnd, ZeeStart, ZeeEnd,THee, Vel, jobID, nSequence);

        return packet;
    }
    void unpack(char *cmdStr) {
        strcpy(packet,cmdStr);
        if(codeSeen('G')) cmdCode=(uint16_t)codeValue();
        if(codeSeen('X')) XeeStart=codeValue();
        if(codeSeen('Y')) XeeEnd=codeValue();
        if(codeSeen('Z')) YeeStart=codeValue();
        if(codeSeen('T')) YeeEnd=codeValue();
        if(codeSeen('V')) ZeeStart=codeValue();
        if(codeSeen('A')) ZeeEnd=codeValue();
        if(codeSeen('B')) THee=codeValue();
        if(codeSeen('C')) Vel=codeValue();
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
    }

} ;
///////////////////////////////////////////////////
class EERotatePacket: public PacketBase
{
    public:
    double XeeStart=0;
    double YeeStart=0;
    double THeeStart=0;
    double THeeEnd=0;
    double Vel=0;

    EERotatePacket() {
        cmdCode = SC_GEN_EEROTATION;
        strcpy(packetName,"EERotatePacket");
    }

    char* pack() {
        sprintf(packet,"G%dX%5.3fY%5.3fZ%5.3fT%5.3fV%5.3fJ%dN%d",
                cmdCode, XeeStart, YeeStart, THeeStart, THeeEnd, Vel, jobID, nSequence);

        return packet;
    }
    void unpack(char *cmdStr) {
        strcpy(packet,cmdStr);
        if(codeSeen('G')) cmdCode=(uint16_t)codeValue();
        if(codeSeen('X')) XeeStart=codeValue();
        if(codeSeen('Y')) YeeStart=codeValue();
        if(codeSeen('Z')) THeeStart=codeValue();
        if(codeSeen('T')) THeeEnd=codeValue();
        if(codeSeen('V')) Vel=codeValue();
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
    }

} ;
///////////////////////////////////////////////////
class PacketResSocketAxisPos: public PacketBase
{
public:
     uint16_t reponseCode=0;
    //pos= [X,R1,R2,Z]
    double pos[4]={0};
    PacketResSocketAxisPos(){
        reponseCode = RC_STATUS_ALL_POS;
        strcpy(packetName,"PacketResSocketAxisPos");
    }

    char* pack() {
        sprintf(packet, "R%d G%d A%5.3f B%5.3f C%5.3f D%5.3f J%d N%d\n",
                reponseCode, cmdCode, pos[0],pos[1],pos[2],pos[3],jobID, nSequence );
        return packet;
    }
    void unpack(char *cmdStr) {
        memset(pos,0,sizeof(double)*4);
        strcpy(packet,cmdStr);
        if(codeSeen('G')) cmdCode=(uint16_t)codeValue();
        if(codeSeen('A')) pos[0]=(double)codeValue();
        if(codeSeen('B')) pos[1]=(double)codeValue();
        if(codeSeen('C')) pos[2]=(double)codeValue();
        if(codeSeen('D')) pos[3]=(double)codeValue();
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint16_t)codeValue();
    }
};
//////////////////////////////////////////////////////////
class PacketCam: public PacketBase
{
public:
    uint16_t mode=0;
    //data[6]=[X, R1, R2, Z, Velocity, Acceleration] for joint
    // or     [Xee, Yee, Thee, Z, Velocity, Acceleration] for cartesian
    // other than that, not used...
    double data[6+2]={0};
public:
    PacketCam() {
        strcpy(packetName,"PacketCam");
    }
    ~PacketCam() {

    }
    PacketCam(PacketCam &other)
        :  PacketBase(other)
    {
        memcpy(data, other.data, sizeof(double)*6);
        mode=other.mode;
        nSequence = other.nSequence;
    }
    PacketCam & operator=(PacketCam & other) {
        if(this==&other) return *this;
        PacketBase::operator=(other);
        memcpy(data, other.data, sizeof(double)*6);
        mode=other.mode;
        nSequence = other.nSequence;
        return *this;
    }
    char* pack() {
        sprintf(packet, "J%dM%dW%5.3fX%5.3fY%5.3fZ%5.3fV%5.3fA%5.3f\n",
                jobID,  mode,
                data[0], data[1], data[2], data[3], data[4], data[5]);
        return packet;
    }

    void unpack(char *cmdStr) {
        memset(data,0,sizeof(double)*6);
        strcpy(packet,cmdStr);
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('M')) mode=(uint16_t)codeValue();
        ///////////////////////////////////////////////
        /// Usage of Data
        // Data[0] = Position X[mm]
        // Data[1] = Position Y[mm]
        // Data[2] = Position Z[mm]
        // Data[3] = Euler Angle X[deg]
        // Data[4] = Euler Angle Y[deg]
        // Data[5] = Euler Angle Z[deg]

        if(codeSeen('W')) data[0]=codeValue();// ,
        if(codeSeen('X')) data[1]=codeValue();//
        if(codeSeen('Y')) data[2]=codeValue();//
        if(codeSeen('Z')) data[3]=codeValue();//
        if(codeSeen('V')) data[4]=codeValue();//
        if(codeSeen('A')) data[5]=codeValue();//

    }
    void unpack() {// unpack from "packet"
        memset(data,0,sizeof(double)*6);
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('M')) mode=(uint16_t)codeValue();

        ///////////////////////////////////////////////
        /// Usage of Data
        // Data[0] = Position X[mm]
        // Data[1] = Position Y[mm]
        // Data[2] = Position Z[mm]
        // Data[3] = Euler Angle X[deg]
        // Data[4] = Euler Angle Y[deg]
        // Data[5] = Euler Angle Z[deg]
        if(codeSeen('W')) data[0]=codeValue();// ,
        if(codeSeen('X')) data[1]=codeValue();//
        if(codeSeen('Y')) data[2]=codeValue();//
        if(codeSeen('Z')) data[3]=codeValue();//
        if(codeSeen('V')) data[4]=codeValue();//
        if(codeSeen('A')) data[5]=codeValue();//
    }

};
//////////////////////////////////////////////////////////
class PacketJobs: public PacketBase
{
public:
    uint16_t mode=0;
    //data[6]=[X, R1, R2, Z, Velocity, Acceleration] for joint
    // or     [Xee, Yee, Thee, Z, Velocity, Acceleration] for cartesian
    // other than that, not used...
    double data[6+2]={0};
public:
    PacketJobs() {
        strcpy(packetName,"PacketJobs");
    }
    ~PacketJobs() {

    }
    PacketJobs(PacketJobs &other)
        :  PacketBase(other)
    {
        memcpy(data, other.data, sizeof(double)*6);
        mode=other.mode;
        nSequence = other.nSequence;
    }
    PacketJobs & operator=(PacketJobs & other) {
        if(this==&other) return *this;
        PacketBase::operator=(other);
        memcpy(data, other.data, sizeof(double)*6);
        mode=other.mode;
        nSequence = other.nSequence;
        return *this;
    }
    char* pack() {
        // J: Job ID
        // N: Sequence Number
        // G: SEND_CMD Command (defined mkglobalclass.h)
        // M: ACTION_MODE Action Mode (defined mkglobalclass.h)
        // W: current EEx position[mm]   - data[0]
        // X: traget EEx position[mm]    - data[1]
        // Y: current EEy position[mm]   - data[2]
        // Z: traget EEy position[mm]    - data[3]
        // V: current EEz position[mm]   - data[4]
        // A: target EEz position[mm]    - data[5]
        // B: current EEtheta [rad]      - data[6]
        // C: EE speed [mm/sec]          - data[7]
        sprintf(packet, "J%dN%dG%dM%dW%5.3fX%5.3fY%5.3fZ%5.3fV%5.3fA%5.3fB%5.3fC%5.3f\n",
                jobID, nSequence, cmdCode, mode,
                data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]);
        return packet;
    }

    void unpack(char *cmdStr) {
        memset(data,0,sizeof(double)*6);
        strcpy(packet,cmdStr);
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint8_t)codeValue();
        if(codeSeen('G')) cmdCode=(uint16_t)codeValue();
        if(codeSeen('M')) mode=(uint16_t)codeValue();
        ///////////////////////////////////////////////
        /// Usage of Data
        ///////////////////////////////////////////////
        // 1. Joint motion
        // Data[0] = X- absolute position
        // Data[1] = R1- absolute position
        // Data[2] = R2- absolute position
        // Data[3] = Z- absolute position
        // Data[4] = percent of max velocity for each axis
        // Data[5] =percent of max acceleration for each axis
        //////////////////////////////////////////////////////
        // 2. Linear Motion
        // Data[0] = EEx position for start
        // Data[1] = EEy Position for start
        // Data[2] = EEx position for end
        // Data[3] = EEy Position for end
        // Data[4] = Angle of End-Effector (deg)
        // Data[5] = speed of EE...
        //////////////////////////////////////////////////////
        // 3. Circular Motion
        // Data[0] = Speed
        // Data[1] = Radius of Circle
        // Data[2] = Center X position of Circle
        // Data[3] = Center Y position of Circle
        // Data[4] = Angle of End-Effector (deg)
        // Data[5] = Amoung of Angle[deg], max = 360 deg...
        //////////////////////////////////////////////////////
        // 4. Spiral Motion
        // Data[0] = Speed
        // Data[1] = Radius of Circle
        // Data[2] = Center X position of Circle
        // Data[3] = Center Y position of Circle
        // Data[4] = Angle of End-Effector (deg)
        // Data[5] = Amoung of Angle[deg], max = 360 deg...
        // Data[6] = Z Xposition of Circle
        // Data[7] = Height of Z movement

        if(codeSeen('W')) data[0]=codeValue();// ,
        if(codeSeen('X')) data[1]=codeValue();//
        if(codeSeen('Y')) data[2]=codeValue();//
        if(codeSeen('Z')) data[3]=codeValue();//
        if(codeSeen('V')) data[4]=codeValue();//
        if(codeSeen('A')) data[5]=codeValue();//
        if(codeSeen('B')) data[6]=codeValue();//
        if(codeSeen('C')) data[7]=codeValue();//
    }
    void unpack() {// unpack from "packet"
        memset(data,0,sizeof(double)*6);
        if(codeSeen('J')) jobID=(uint16_t)codeValue();
        if(codeSeen('N')) nSequence=(uint8_t)codeValue();
        if(codeSeen('G')) cmdCode=(uint16_t)codeValue();
        if(codeSeen('M')) mode=(uint16_t)codeValue();
        ///////////////////////////////////////////////
        /// Usage of Data
        ///////////////////////////////////////////////
        // 1. Joint motion
        // Data[0] = X- absolute position
        // Data[1] = R1- absolute position
        // Data[2] = R2- absolute position
        // Data[3] = Z- absolute position
        // Data[4] = percent of max velocity for each axis
        // Data[5] =percent of max acceleration for each axis
        //////////////////////////////////////////////////////
        // 2. Linear Motion
        // Data[0] = EEx position for start
        // Data[1] = EEy Position for start
        // Data[2] = EEx position for end
        // Data[3] = EEy Position for end
        // Data[4] = Angle of End-Effector (deg)
        // Data[5] = speed of EE...
        //////////////////////////////////////////////////////
        // 3. Circular Motion
        // Data[0] = Speed
        // Data[1] = Radius of Circle
        // Data[2] = Center X position of Circle
        // Data[3] = Center Y position of Circle
        // Data[4] = Angle of End-Effector (deg)
        // Data[5] = Amoung of Angle[deg], max = 360 deg...
        //////////////////////////////////////////////////////
        // 4. Spiral Motion
        // Data[0] = Speed
        // Data[1] = Radius of Circle
        // Data[2] = Center X position of Circle
        // Data[3] = Center Y position of Circle
        // Data[4] = Angle of End-Effector (deg)
        // Data[5] = Amoung of Angle[deg], max = 360 deg...
        // Data[6] = Z Xposition of Circle
        // Data[7] = Height of Z movement

        if(codeSeen('W')) data[0]=codeValue();// ,
        if(codeSeen('X')) data[1]=codeValue();//
        if(codeSeen('Y')) data[2]=codeValue();//
        if(codeSeen('Z')) data[3]=codeValue();//
        if(codeSeen('V')) data[4]=codeValue();//
        if(codeSeen('A')) data[5]=codeValue();//
        if(codeSeen('B')) data[6]=codeValue();//
        if(codeSeen('C')) data[7]=codeValue();//
    }
    int getSequenceNumber() {
        if(codeSeen('N')) {
            return codeValue();
        }
        return -1;
    }
    bool isEndOfSequence() {
        if(getSequenceNumber()==0) return true;
        return false;
    }
};
/////////////////////////////////////////////
///////////////////////////////////////////////////
typedef struct _ROBOT_PROPERTY_
{

    //PacketSpeedProfile packetHoming;
    double homingPosStage[3], homingVelStage[3], homingAccelStage[3];
    JOINT_TYPE jointType = JT_LIN;
    int ID=-1; // robot Channel
    int cmdCode=-1; // R: command code
    int opMode=STOPPED;// Operation mode : OP_MODE {ERROR=0, STOPPED, MOVING, JOB_DONE, HOMING };
    int jobID=0;

    int32_t absSteps=0; // absoulte stepper motor count
    double STEP2DIST=0;
    double DIST2STEP=0;
    double LEADPITCH=0;

    int32_t MICROSTEPPING=0;
    int homeSM=-1; // Home S/W state machine (0: s/w off, 1: s/w on, 2: s/w on->off, 3: s/w off->off)
    int homeSW=-1; // Home S/W On/Off(1,0)
    int endStopSW=-1;
    int processStatus=-1;
    bool isShutDown=false;
    double gearRatio=0;

    double maxDistance=0;
    double centerPos=0;// from Homing End-Stop to the center line for R1, R2 Joint...
    double maxVel=0;
    double maxAccel=0;
    bool isSelected=false;// When send multi-axis data, it determines which axis will be sent...
    double nextMoveSteps = 0; // It stores the next Steps from current absSteps for move(absolute step position)...

    // If JT_ROT, unit is [Deg], otherwise [mm]
    double getDistanceFromStep()
    {
        // cout<<"getDistanceFromStep(): absSteps="<<absSteps<<", step2dist="<<STEP2DIST<<endl;
        if(jointType==JT_ROT)// OUTPUT DEGREE
            return absSteps*STEP2DIST*180.0/M_PI;
        return absSteps*STEP2DIST;
    }
    // If JT_ROT, input [Deg] and output is steps [pulse]
    double getStepsFromDistance(double dist)
    {
        if(jointType==JT_ROT)// Input Degree
            return dist*DIST2STEP*M_PI/180.0;// [rad]
        return dist*DIST2STEP;
    }
    // If JT_ROT, input [Deg] otherwise [mm] and output is steps
    double setNextStepsFromDistance(double dist)
    {

        if(jointType==JT_ROT){
            // Input Degree
            nextMoveSteps =  dist*DIST2STEP*M_PI/180.0;// [rad]
            return nextMoveSteps;
        }
        nextMoveSteps =  dist*DIST2STEP;
        return nextMoveSteps;
    }
    double getAlpha()
    {
        return (2.0*M_PI/MICROSTEPPING);
    }
    // If JT_ROT, output is [Deg/s], otherwise [mm/2]
    double getMaxVel()
    {
        if(jointType==JT_ROT)
            return maxVel*180.0/M_PI;
        return maxVel;
    }
    // If JT_ROT, output is [Deg/s^2], otherwise [mm/s^2]
    double getMaxAccel()
    {
        if(jointType==JT_ROT)
            return maxAccel*180.0/M_PI;
        return maxAccel;
    }
    // If JT_ROT, output is [Deg], otherwise [mm]
    double getMaxDistance()
    {
        if(jointType==JT_ROT)
            return maxDistance*180.0/M_PI;
        return maxDistance;
    }
    // If JT_ROT, output is [Deg], otherwise [mm]
    std::string getUnit() {
        if(jointType==JT_ROT) return "[deg]";
        return "[mm]";
    }
    int getJointType()
    {
        return jointType;
    }

    void print()
    {
        cout<<"\n\033[1;36m--------------------------------- robot params -----------------------------------\033[0m\n";
        cout<<"\033[1;36mMotor ID="<<ID<<": \033[0mDIST2STEP="<<DIST2STEP<<", STEP2DIST="<<STEP2DIST<<", LEADPITCH="<<LEADPITCH<<endl;

        cout<<"\033[1;36mStatus: \033[0m";
        cout<<"CMD:"<<cmdCode<<", POS:"<<absSteps<<", Op:"<<opMode<<", process:"<<processStatus<<endl;
    }

}RobotProperty;
#endif // MKGLOBALCLASS_H
