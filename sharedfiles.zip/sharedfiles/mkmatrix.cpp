#include <time.h>
#include <fstream>
#include <stdlib.h>
#include "../sharedfiles/mkmatrix.h"
#include <qdebug.h>
//#ifndef min
#define MIN(x, y) (((x) < (y)) ? (x) : (y))
//#endif

//#ifndef max
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
//#endif

#ifdef _DEBUG
int mkMatrix::m_NextObjectNumber = 1 ;
#endif

//extern stBoneData Femur, Tibia;
mkMatrix::mkMatrix()
{
#ifdef _DEBUG
    // so we can regonise each individual object
//	m_ObjectNumber = m_NextObjectNumber++ ;
///	TRACE("Creating mkMatrix object %1d - default constructor\n", m_ObjectNumber) ;
#endif
    // default constructor, create a 1 * 1 array
    m_nCol = 1 ;
    m_nRow = 1 ;
    m_nRow_original=m_nRow;
    m_nCol_original=m_nCol;
    m_pData = NULL ;
    m_ppData=NULL;

    m_bNULL=false;
    m_pData = AllocateMemory(m_nRow, m_nCol ) ;
    m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;

    IncrementReferenceCount() ;			// count the reference to this memory
}

mkMatrix::mkMatrix(const mkMatrix &other)
{
#ifdef _DEBUG
    // so we can regonise each individual object
    m_ObjectNumber = m_NextObjectNumber++ ;
///	TRACE("Creating mkMatrix object %1d - copy constructor other = %1d\n", m_ObjectNumber, other.m_ObjectNumber) ;
#endif
    // copy constructor
    m_bNULL=false;
    m_pData = NULL ;
    m_ppData = NULL ;
    // use the other objects data pointer
    m_nCol = other.m_nCol ;
    m_nRow = other.m_nRow ;
    //m_pData = other.m_pData ;				// copy the pointer
    m_pData = AllocateMemory(m_nRow, m_nCol ) ;
    m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;

    memcpy((double*)m_pData, (double*)other.m_pData, sizeof(double)*m_nCol*m_nRow);
    IncrementReferenceCount() ;				// this thread can get the mutex multiple times without blocking
}

mkMatrix::mkMatrix(int nRows,int nCols )
{
#ifdef _DEBUG
    // so we can regonise each individual object
    m_ObjectNumber = m_NextObjectNumber++ ;
///	TRACE("Creating mkMatrix object %1d - size constructor\n", m_ObjectNumber) ;
#endif
    // size constructor
//    // _ASSERT(nCols > 0) ;					// matrix size error
//    // _ASSERT(nRows > 0) ;					// matrix size error
    m_bNULL=false;
    m_pData = NULL ;
    m_ppData = NULL ;
    m_nCol = nCols ;
    m_nRow = nRows ;
    m_pData = AllocateMemory(m_nRow, m_nCol ) ;
    m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
    IncrementReferenceCount() ;				// count the reference to this memory
}

mkMatrix::mkMatrix(int size, bool set_diagonal)
{
    // construct a square matrix with 1.0's on the diagonal if required
#ifdef _DEBUG
    // so we can regonise each individual object
    m_ObjectNumber = m_NextObjectNumber++ ;
///	TRACE("Creating mkMatrix object %1d - square size constructor\n", m_ObjectNumber) ;
#endif
    // size constructor
   // // _ASSERT(size > 0) ;						// matrix size error
    m_bNULL=false;
    m_pData = NULL ;
    m_ppData = NULL ;
    m_nCol = size ;
    m_nRow = size ;
    m_pData = AllocateMemory(m_nRow, m_nCol ) ;
    m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
    IncrementReferenceCount() ;				// count the reference to this memory
    // set the dialognal if required
    if (set_diagonal)
        {
        for (int i = 0 ; i < size ; ++i)
            SetElement(i, i, 1.0) ;
        }
}
mkMatrix::mkMatrix(int r, int c, double * pData)
{
    m_bNULL=false;
    m_pData = NULL ;
    m_ppData = NULL ;
        m_nCol = c ;
        m_nRow = r ;
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        memcpy((double*)m_pData, (double*)pData, sizeof(double)*c*r);
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        IncrementReferenceCount() ;
    //for(int i=0;i<c; i++)
    //	for(int j=0; j<r; j++)
    //		SetElement(i,j,pData[]);

}
void mkMatrix::SetData(int r, int c, double * pData)
{
        DecrementAndRelease();
        m_nCol = c ;
        m_nRow = r ;
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        memcpy((double*)m_pData, (double*)pData, sizeof(double)*c*r);
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        IncrementReferenceCount() ;
}
// Make 4x1 colume vector from array[3]...
void mkMatrix::SetColVector( double * pData)
{
        DecrementAndRelease();
        m_nCol = 1 ;
        m_nRow = 4 ;
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        memcpy((double*)m_pData, (double*)pData, sizeof(double)*3);
        m_pData[3]=1.0;
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        IncrementReferenceCount() ;
}
void mkMatrix::GetColVector( double * pData)
{
      memcpy((double*)pData , (double*)m_pData, sizeof(double)*3);
}

mkMatrix::~mkMatrix()
{
#ifdef _DEBUG
//	TRACE("Destroying mkMatrix object %1d\n", m_ObjectNumber) ;
#endif
    DecrementAndRelease() ;			// free's m_pData if no other references
}

void mkMatrix::Resize(int nr, int nc)
{
    if((nr==m_nRow_original)&&(nc==m_nCol_original))
        if((m_nRow==m_nRow_original)&&(m_nCol==m_nCol_original))
            return;

    //TRACE("nr=%d,nc=%d\n", nr, nc);
    //if((nr>m_nRow_original)||(nc>m_nCol_original))
    //	printf("nr=%d,nc=%d\n", nr, nc);
   //// _ASSERT(nr<=m_nRow_original);
   // // _ASSERT(nc<=m_nCol_original);
    m_nRow=nr;
    m_nCol=nc;
    for(int i=0; i<m_nRow; i++)
    {
        m_ppData[i]=&m_pData[i*m_nCol];
    }
}
void mkMatrix::SetOriginalSize()
{
    m_nRow=m_nRow_original;
    m_nCol=m_nCol_original;
    for(int i=0; i<m_nRow; i++)
    {
        m_ppData[i]=&m_pData[i*m_nCol];
    }
}

double** mkMatrix::Make2Dim(double *pData,int nRows, int nCols)
{
    ////////////////////////////////////////////////
    // m_ppData[r][c] can be used for arrytype access...
    //double **ppData=(double **)malloc((size_t)sizeof(double*)*nRows);

    double **ppData= new double *[(size_t)sizeof(double*)*nRows];

   // // _ASSERT(ppData != NULL) ;					// allocation error
    for(int i=0; i<nRows; i++)
    {
        ppData[i]=&pData[i*nCols];
    }

    return ppData;

}
double* mkMatrix::AllocateMemory(int nRows, int nCols)
{
   // // _ASSERT(nCols > 0) ;							// size error
   // // _ASSERT(nRows > 0) ;							// size error
    // allocates heap memory for an array
    double	*pData = NULL ;

    m_nRow_original=m_nRow;
    m_nCol_original=m_nCol;

    pData = new double[nCols * nRows + 1] ;			// all in one allocation (+1 for reference count)
   // // _ASSERT(pData != NULL) ;					// allocation error
  //  // _ASSERT(FALSE == IsBadReadPtr(pData, sizeof(double) * (nCols * nRows + 1))) ;
    // empty the memory
    memset(pData, 0, sizeof(double) * (nCols * nRows + 1)) ;		// starts with a 0 reference count


    return pData ;
}

mkMatrix& mkMatrix::operator=(const mkMatrix &other)
{
    if (&other == this)
        return *this ;
    // this does the same job as a copy constructor except we have to de-allocate any
    // memory we may have already allocated
    DecrementAndRelease() ;			// free's m_pData if no other references
    // now copy the other matrix into ourselves
    // use the other objects data pointer
    m_nCol = other.m_nCol ;
    m_nRow = other.m_nRow ;
    //m_pData = other.m_pData ;				// copy the pointer
    m_pData =AllocateMemory(m_nRow, m_nCol );
    memcpy((double*)m_pData, (double *)other.m_pData, sizeof(double)*m_nRow*m_nCol);
    m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
    IncrementReferenceCount() ;				// this thread can get the mutex multiple times without blocking
    // finally return a reference to ourselves
    return *this ;
}

bool mkMatrix::operator==(const mkMatrix &other) const
{
    // only return true if the matrices are exactly the same
    if (&other == this)
        return true ;		// comparing to ourselves
    if (m_pData == other.m_pData)
        return true ;		// both pointing to same data, must be same
    if (m_nCol != other.m_nCol || m_nRow != other.m_nRow)
        return false ;		// different dimensions
    if (memcmp(m_pData, other.m_pData, sizeof(double) * m_nCol * m_nRow) == 0)
        return true ;		// buffers are the same
    return false ;			// must be different
}

mkMatrix mkMatrix::operator+(const mkMatrix &other) const
{
    // first check for a valid addition operation
    if (m_nCol != other.m_nCol)
        throw "Invalid operation" ;
    if (m_nRow != other.m_nRow)
        throw "Invalid operation" ;
    // now that we know that the operation is possible
   // // _ASSERT(FALSE == IsBadReadPtr(other.m_pData, sizeof(double) * other.m_nCol * other.m_nRow)) ;
    // construct the object we are going to return
    mkMatrix		result(*this) ;		// copy ourselves
    // now add in the other matrix
    for (int i = 0 ; i < m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            result.SetElement(i, j, result.GetElement(i, j) + other.GetElement(i, j)) ;
        }
    return result ;
}

mkMatrix mkMatrix::operator-(const mkMatrix &other) const
{
    // first check for a valid subtraction operation
    if (m_nCol != other.m_nCol)
        throw "Invalid operation" ;
    if (m_nRow != other.m_nRow)
        throw "Invalid operation" ;
    // now that we know that the operation is possible
   // // _ASSERT(FALSE == IsBadReadPtr(other.m_pData, sizeof(double) * other.m_nCol * other.m_nRow)) ;
    // construct the object we are going to return
    mkMatrix		result(*this) ;		// copy ourselves
    // now subtract the other matrix
    for (int i = 0 ; i < m_nRow  ; ++i)
        {
        for (int j = 0 ; j <  m_nCol; ++j)
            result.SetElement(i, j, result.GetElement(i, j) - other.GetElement(i, j)) ;
        }
    return result ;
}

mkMatrix mkMatrix::operator*(const mkMatrix &other) const
{
    // first check for a valid multiplication operation
    if (m_nCol  != other.m_nRow)
    //if (m_nCol != other.m_nRow)
        throw "Matrices do not have common size" ;
    // now that we know that the operation is possible
   // // _ASSERT(FALSE == IsBadReadPtr(other.m_pData, sizeof(double) * other.m_nCol * other.m_nRow)) ;
    // construct the object we are going to return
    //mkMatrix		result(m_nCol, other.m_nRow) ;
    mkMatrix		result(m_nRow, other.m_nCol) ;

    // e.g.
    // [A][B][C]   [G][H]     [A*G + B*I + C*K][A*H + B*J + C*L]
    // [D][E][F] * [I][J] =   [D*G + E*I + F*K][D*H + E*J + F*L]
    //             [K][L]
    //
    double	 value ;
    int i, j, k;
    for ( i = 0 ; i < result.m_nRow ; ++i)
        {
        for ( j = 0 ; j < result.m_nCol  ; ++j)
            {
            value = 0.0 ;
            for ( k = 0 ; k < m_nCol ; ++k)
                {
                value += GetElement(i, k) * other.GetElement(k, j) ;
                }
            result.SetElement(i, j, value) ;
            }
        }
    return result ;
}

void mkMatrix::operator+=(const mkMatrix &other)
{
    // first check for a valid addition operation
    if (m_nCol != other.m_nCol)
        throw "Invalid operation" ;
    if (m_nRow != other.m_nRow)
        throw "Invalid operation" ;
    // now that we know that the operation is possible
   // // _ASSERT(FALSE == IsBadReadPtr(other.m_pData, sizeof(double) * other.m_nCol * other.m_nRow)) ;
    // now add in the other matrix
    for (int i = 0 ; i < m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            SetElement(i, j, GetElement(i, j) + other.GetElement(i, j)) ;
        }
}

void mkMatrix::operator-=(const mkMatrix &other)
{
    // first check for a valid subtraction operation
    if (m_nCol != other.m_nCol)
        throw "Invalid operation" ;
    if (m_nRow != other.m_nRow)
        throw "Invalid operation" ;
    // now that we know that the operation is possible
    //// _ASSERT(FALSE == IsBadReadPtr(other.m_pData, sizeof(double) * other.m_nCol * other.m_nRow)) ;
    // now subtract the other matrix
    for (int i = 0 ; i < m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            SetElement(i, j, GetElement(i, j) - other.GetElement(i, j)) ;
        }
}

void mkMatrix::operator*=(const mkMatrix &other)
{
    // first check for a valid multiplication operation
    if (m_nRow != other.m_nCol)
        throw "Matrices do not have common size" ;

    *this = *this * other ;
}

void mkMatrix::operator*=(double value)
{
    // just multiply the elements by the value
    for (int i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            SetElement(i, j, GetElement(i, j) * value) ;
            }
        }
}
void mkMatrix::operator/=(double value)
{
    // just multiply the elements by the value
    for (int i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            SetElement(i, j, GetElement(i, j) / value) ;
            }
        }
}
////////////////////////////////////////////
// ++ MKIM
void mkMatrix::operator-=(double value)
{
    // just multiply the elements by the value
    for (int i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            SetElement(i, j, GetElement(i, j) - value) ;
            }
        }
}
void mkMatrix::operator+=(double value)
{
    // just multiply the elements by the value
    for (int i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            SetElement(i, j, GetElement(i, j) + value) ;
            }
        }
}
// -- MKIM
////////////////////////////////////////////////////////////////////////////
// mkMatrixHelper is only used for this to simulate a mkMatrix::operator[][]
//const mkMatrixHelper mkMatrix::operator[](int nCol) const
//{
//   // // _ASSERT(nCol >= 0) ;							// array bounds error
//   // // _ASSERT(nCol < m_nCol) ;				// array bounds error
//    // construc the mkMatrixHelper object to allow operator[][] to work
//    mkMatrixHelper	mh(this, nCol) ;
//    return mh ;
//}

//mkMatrixHelper mkMatrix::operator[](int nCol)
//{
//   // // _ASSERT(nCol >= 0) ;							// array bounds error
//   // // _ASSERT(nCol < m_nCol) ;				// array bounds error
//    // construc the mkMatrixHelper object to allow operator[][] to work
//    mkMatrixHelper	mh(this, nCol) ;
//    return mh ;
//}

bool mkMatrix::SetElement(int nRow,int nCol,  double value)
{
    // first check the reference count on our data object to see whether we need to create a copy
    if (GetReferenceCount() > 1)
        {
        // we need to make a copy
        double	*pData = m_pData ;				// take a copy of the pointer
        DecrementReferenceCount() ;				// decrement the current reference count
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        memcpy(m_pData, pData, sizeof(double) * m_nCol * m_nRow) ;
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        IncrementReferenceCount() ;				// increment the new data's reference count
        }
  //  // _ASSERT(nCol >= 0) ;							// array bounds error
  //  // _ASSERT(nCol < m_nCol) ;						// array bounds error
  //  // _ASSERT(nRow >= 0) ;							// array bounds error
 //   // _ASSERT(nRow < m_nRow) ;						// array bounds error
 //   // _ASSERT(m_pData) ;							// bad pointer error
    m_pData[nCol + nRow * m_nCol] = value ;
    return true ;
}

#ifdef _DEBUG
// release version is in-line
double mkMatrix::GetElement(int nRow, int nCol) const
{
    // _ASSERT(nCol >= 0) ;							// array bounds error
    // _ASSERT(nCol < m_nCol) ;						// array bounds error
    // _ASSERT(nRow >= 0) ;							// array bounds error
    // _ASSERT(nRow < m_nRow) ;						// array bounds error
    // _ASSERT(m_pData) ;							// bad pointer error
    return m_pData[nCol + nRow * m_nCol] ;
}
#endif

//
// To avoid big hits when constructing and assigning mkMatrix objects, multiple mkMatrix's can reference
// the same m_pData member. Only when a matrix becomes different from the other does a new version of the array
// get created and worked with.
//
void mkMatrix::IncrementReferenceCount()
{
    // get a pointer to the end of the m_pData object where the reference count resides
    int*	pReference = (int*)&m_pData[m_nCol * m_nRow] ;
    ++(*pReference) ;				// increment the reference count
    // done!
}

void mkMatrix::DecrementReferenceCount()
{
    // get a pointer to the end of the m_pData object where the reference count resides
    int*	pReference = (int*)&m_pData[m_nCol * m_nRow] ;
    --(*pReference) ;				// decrement the reference count
    // done!
}

void mkMatrix::DecrementAndRelease()
{
    // get a pointer to the end of the m_pData object where the reference count resides
    if(m_pData==NULL)
        return;

    int*	pReference = (int*)&m_pData[m_nCol * m_nRow] ;
    --(*pReference) ;				// decrement the reference count
    //if (*pReference == 0)
        {
        // the memory is no longer needed, release it
        if(m_pData!=NULL)
            delete []m_pData ;
        m_pData = NULL ;
        if(m_ppData!=NULL)
            delete [] m_ppData;
            //free(m_ppData);
        m_ppData=NULL;
        }
    // done!
}

int mkMatrix::GetReferenceCount() const
{
    // get a pointer to the end of the m_pData object where the reference count resides
    int*	pReference = (int*)&m_pData[m_nCol * m_nRow] ;
    return *pReference ;
}

mkMatrix mkMatrix::GetTransposed() const
{
    mkMatrix	transposed(*this) ;		// make a copy of ourselves

    transposed.Transpose() ;
    return transposed ;
}

void mkMatrix::Transpose()
{
    // first check the reference count on our data object to see whether we need to create a copy
    mkMatrix	mcopy(*this) ;
    // swap the x/y values
    int	copy = m_nCol ;
    m_nCol = m_nRow ;
    m_nRow = copy ;
    // copy across the transposed data
    for (int i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            SetElement(i, j, mcopy.m_ppData[j][i]) ;
        }
}

mkMatrix mkMatrix::GetInverted() const
{
    // matrix inversion will only work on square matrices
    if (m_nCol != m_nRow)
        throw "Matrix must be square." ;
    // return this matrix inverted
    mkMatrix	copy(*this) ;
    copy.Invert() ;

    return copy ;
}

mkMatrix mkMatrix::Invert()
{
    // matrix inversion will only work on square matrices
    // invert ourselves
    if (m_nCol != m_nRow)
        throw "Matrix must be square." ;
    mkMatrix Inv;
    Inv = *this;
    double	e ;
    int k,j,  i;
    for ( k = 0 ; k < m_nRow ; ++k)
        {
        e = GetElement(k, k) ;
        //Inv.SetElement(k, k, 1.0) ;
        SetElement(k, k, 1.0) ;
        if (e == 0.0)
            throw "Matrix inversion error" ;
        for ( j = 0 ; j < m_nRow ; ++j)
            //Inv.SetElement(k, j, GetElement(k, j) / e) ;
            SetElement(k, j, GetElement(k, j) / e) ;
        for ( i = 0 ; i < m_nRow ; ++i)
            {
            if (i != k)
                {
                e = GetElement(i, k) ;
                //Inv.SetElement(i, k, 0.0) ;
                SetElement(i, k, 0.0) ;

                for (j = 0 ; j < m_nRow ; ++j)
                    //Inv.SetElement(i, j, GetElement(i, j) - e * GetElement(k, j)) ;
                    SetElement(i, j, GetElement(i, j) - e * GetElement(k, j)) ;
                }
            }
        }
    return Inv;
}

// A' * A
mkMatrix mkMatrix::Covariant() const
{
    mkMatrix	result ;
    mkMatrix trans(GetTransposed()) ;
    //trans.WriteAsCSVFile("trans.txt");
    result =  trans* (*this) ;
    return result ;
}

mkMatrix mkMatrix::ExtractSubMatrix(int row_start,int col_start,  int col_size, int row_size) const
{
    // _ASSERT(col_start >= 0) ;						// bad start index
    // _ASSERT(row_start >= 0) ;						// bad start index
    // _ASSERT(col_size > 0) ;						// bad size
    // _ASSERT(row_size > 0) ;						// bad size
    // make sure the requested sub matrix is in the current matrix
    if (col_start + col_size > m_nCol)
        throw "Sub matrix is not contained in source" ;
    if (row_start + row_size > m_nRow)
        throw "Sub matrix is not contained in source" ;

    mkMatrix sub(row_size,col_size ) ;

    for (int i = 0 ; i < row_size  ; ++i)
        {
        for (int j = 0 ; j <  col_size; ++j)
            {
            sub.SetElement(i, j, GetElement(row_start  + i, col_start + j)) ;
            }
        }
    return sub ;
}

void mkMatrix::CopyData(int rs, int cs,int rw, int cw, double *pData)
{

    // _ASSERT(rs >= 0) ;						// bad start index
    // _ASSERT(cs >= 0) ;						// bad start index
    // _ASSERT(cs + cw <= m_nCol) ;	// bad size
    // _ASSERT(rs + rw <= m_nRow) ;	// bad size

    for(int i=0;i<rw; i++)
        for(int j=0; j<cw; j++)
        {
            //SetElement(rs+i,cs+j,pData[i*cw+j]);
            m_ppData[rs  + i][cs  + j]=pData[i*cw+j];
        }



}
void mkMatrix::SetSubMatrix(int row_start,int col_start,  const mkMatrix &other)
{
    // _ASSERT(col_start >= 0) ;						// bad start index
    // _ASSERT(row_start >= 0) ;						// bad start index
    // _ASSERT(col_start + other.m_nCol <= m_nCol) ;	// bad size
    // _ASSERT(row_start + other.m_nRow <= m_nRow) ;	// bad size
    for (int i = 0 ; i < other.m_nRow  ; ++i)
        {
        for (int j = 0 ; j <  other.m_nCol; ++j)
            {
                m_ppData[row_start  + i][col_start  + j]=other.m_ppData[i][j];
                //SetElement(row_start  + i,col_start  + j, other.GetElement(i, j)) ;
            }
        }
}

mkMatrix mkMatrix::ExtractDiagonal() const
{
    if (m_nCol != m_nRow)
        throw "Can only extract diagonal from square matrix" ;
    mkMatrix	diagonal(m_nCol, 1) ;

    for (int i = 0 ; i < m_nCol ; ++i)
        diagonal.SetElement(i, 0, GetElement(i, i)) ;
    return diagonal ;
}


mkMatrix mkMatrix::GetConcatinatedColumns(const mkMatrix& other) const
{
    if (m_nRow != other.m_nRow)
        throw "Cannot concatenate matrices, not same size" ;
    // copy ourselves and then return the concatenated result
    mkMatrix		result(*this) ;

    result.ConcatinateColumns(other) ;
    return result ;
}

// concatinate the other matrix to ourselves
void mkMatrix::ConcatinateColumns(const mkMatrix &other)
{
    if (m_nRow != other.m_nRow)
        throw "Cannot concatenate matrices, not same size" ;
    // create a matrix big enough to hold both
    mkMatrix		result(m_nRow, m_nCol + other.m_nCol ) ;

    // now populate it
    int i;
    for ( i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            result.SetElement(i, j, GetElement(i, j)) ;
            }
        }
    // now add the other matrix
    for (i = 0 ; i < m_nRow  ; ++i)
        {
        for (int j = 0 ; j < other.m_nCol ; ++j)
            {
            result.SetElement(i , j+ m_nCol, other.GetElement(i, j)) ;
            }
        }
    *this = result ;					// assign it to us
}

mkMatrix mkMatrix::GetConcatinatedRows(const mkMatrix& other) const
{
    if (m_nCol != other.m_nCol)
        throw "Cannot concatenate matrices, not same size" ;
    // copy ourselves and then return the concatenated result
    mkMatrix		result(*this) ;

    result.ConcatinateRows(other) ;
    return result ;
}

void mkMatrix::ConcatinateRows(const mkMatrix &other)
{
    if (m_nCol != other.m_nCol)
        throw "Cannot concatenate matrices, not same size" ;
    // create a matrix big enough to hold both
    mkMatrix		result( m_nRow + other.m_nRow, m_nCol) ;

    // now populate it
    int i;
    for ( i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            result.SetElement(i, j, GetElement(i, j)) ;
            }
        }
    // now add the other matrix
    for (i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < other.m_nCol ; ++j)
            {
            result.SetElement(i+ m_nRow, j , other.GetElement(i, j)) ;
            }
        }
    *this = result ;					// assign it to us
}

void mkMatrix::AddColumn(const double *pData)
{
    // _ASSERT(FALSE == IsBadReadPtr(pData, sizeof(double) * m_nRow)) ;

    mkMatrix	result( m_nRow,m_nCol + 1) ;			// costruct the result

    result.SetSubMatrix(0, 0, *this) ;				// copy ouselves across
    // now add the new row
    for (int i = 0 ; i < m_nRow ; ++i)
        {
        result.SetElement( i,m_nCol, pData[i]) ;
        }
    *this = result ;								// assign result to us
}

void mkMatrix::AddRow(const double *pData)
{
    // _ASSERT(FALSE == IsBadReadPtr(pData, sizeof(double) * m_nCol)) ;

    mkMatrix	result( m_nRow + 1,m_nCol) ;			// costruct the result

    result.SetSubMatrix(0, 0, *this) ;				// copy ouselves across
    // now add the new row
    for (int i = 0 ; i < m_nCol ; ++i)
        {
        result.SetElement(m_nRow,i,  pData[i]) ;
        }
    *this = result ;								// assign result to us
}

mkMatrix	operator*(const mkMatrix &other, double value)
{
    mkMatrix copy(other) ;

    // just multiply the elements by the value
    for (int i = 0 ; i <copy.m_nRow  ; ++i)
        {
        for (int j = 0 ; j < copy.m_nCol ; ++j)
            {
            copy.SetElement(i, j, copy.GetElement(i, j) * value) ;
            }
        }
    return copy ;
}
mkMatrix	operator/(const mkMatrix &other, double value)
{
    mkMatrix copy(other) ;

    // just multiply the elements by the value
    for (int i = 0 ; i <copy.m_nRow  ; ++i)
        {
        for (int j = 0 ; j < copy.m_nCol ; ++j)
            {
            copy.SetElement(i, j, copy.GetElement(i, j) / value) ;
            }
        }
    return copy ;
}
////////////////////////////////////////////////////
// ++ MKIM
mkMatrix	operator+(const mkMatrix &other, double value)
{
    mkMatrix copy(other) ;

    // just multiply the elements by the value
    for (int i = 0 ; i <copy.m_nRow  ; ++i)
        {
        for (int j = 0 ; j < copy.m_nCol ; ++j)
            {
            copy.SetElement(i, j, copy.GetElement(i, j) + value) ;
            }
        }
    return copy ;
}
mkMatrix	operator-(const mkMatrix &other, double value)
{
    mkMatrix copy(other) ;

    // just multiply the elements by the value
    for (int i = 0 ; i <copy.m_nRow  ; ++i)
        {
        for (int j = 0 ; j < copy.m_nCol ; ++j)
            {
            copy.SetElement(i, j, copy.GetElement(i, j) - value) ;
            }
        }
    return copy ;
}

// -- MKIM
///////////////////////////////////////////////////////////
mkMatrix mkMatrix::GetSquareMatrix() const
{
    mkMatrix	copy(*this) ;

    copy.MakeSquare() ;
    return copy ;
}

void mkMatrix::MakeSquare()
{
    // make the current matrix square by either stepping in the x or y directions
    // square to the smallest side
    int size = m_nCol ;
    if (size > m_nRow)
        size = m_nRow ;

    mkMatrix	work(size, size) ;				// construct result
    double	x_step = m_nCol / size ;
    double	y_step = m_nRow / size ;

    for (int i = 0 ; i < size ; ++i)
        {
        for (int j = 0 ; j < size ; ++j)
            work.SetElement(i, j, GetElement((int)(i * x_step), (int)(j * y_step))) ;
        }
    *this = work ;				// copy the result to ourselves
}

mkMatrix mkMatrix::GetNormalised(double min, double max) const
{
    mkMatrix copy(*this) ;
    copy.Normalise(min, max) ;
    return copy ;
}

void mkMatrix::Normalise(double min, double max)
{
    // get the lower and upper limit values in the matrix
    // we use the range to normalise
    double	e_min ;
    double	e_max ;

    GetNumericRange(e_min, e_max) ;

    double	range = e_max - e_min ;
    double	r_range = max - min ;			// required range
    double	value ;
    for (int i = 0 ; i <m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            value = GetElement(i, j) ;
            value -= e_min ;			// 0 - range
            value /= range ;
            value *= r_range ;
            value += min ;
            SetElement(i, j, value) ;
            }
        }
}

// gets the lowest and highest values in the matrix
void mkMatrix::GetNumericRange(double &min, double &max) const
{
    double	e_min = GetElement(0, 0) ;
    double	e_max = e_min ;
    double	value ;

    for (int i = 0 ; i < m_nRow  ; ++i)
        {
        for (int j = 0 ; j < m_nCol ; ++j)
            {
            value = GetElement(i, j) ;
            if (value < e_min)
                e_min = value ;
            else if (value > e_max)
                e_max = value ;
            }
        }
    min = e_min ;
    max = e_max ;
}
double mkMatrix::SumAll() const
{
    double sum=0.0;
    for (int i = 0 ; i < m_nRow  ; ++i)
    {
        for(int j=0; j<m_nCol; j++)
            sum += m_ppData[i][j];
    }
    return sum;
}
double mkMatrix::SumColumn(int column) const
{
    // _ASSERT(column >= 0) ;					// bad column
    // _ASSERT(column < m_nCol) ;				// bad column
    double	sum = 0.0 ;

    for (int i = 0 ; i < m_nRow ; ++i)
        sum += GetElement( i,column) ;
    return sum ;
}

double mkMatrix::SumRow(int row) const
{
    // _ASSERT(row >= 0) ;						// bad row
    // _ASSERT(row < m_nRow) ;					// bad row
    double	sum = 0.0 ;

    for (int i = 0 ; i < m_nCol ; ++i)
        sum += GetElement( row,i) ;
    return sum ;
}

double mkMatrix::SumColumnSquared(int column) const
{
    double value = SumColumn(column) ;
    return (value * value) ;
}

double mkMatrix::SumRowSquared(int row) const
{
    double value = SumRow(row) ;
    return (value * value) ;
}

// returns the minimum value in a row of the matrix
double mkMatrix::GetRowMin(int row) const
{
    // _ASSERT(row >= 0) ;
    // _ASSERT(row < m_nRow) ;
    double	value = GetElement(row,0) ;
    for (int i = 0 ; i < m_nCol ; ++i)
        {
        if (GetElement(row,i) < value)
            value = GetElement(row,i) ;
        }
    return value ;
}
int mkMatrix::GetRowMinIndex(int row) const
{
    // _ASSERT(row >= 0) ;
    // _ASSERT(row < m_nRow) ;
    double	value = GetElement(row,0) ;
    int index=0;
    for (int i = 0 ; i < m_nCol ; ++i)
    {
        if (GetElement(row,i) < value){
            index = i;
            value = GetElement(row,i) ;
        }
    }
    return index ;
}
int mkMatrix::GetAbsMinIndex() const
{
    double minValue=1.0e17;
    int minIndex=0;
    for (int i = 0 ; i < m_nRow  ; ++i)
    {
        for(int j=0; j<m_nCol; j++){
            if (abs(m_ppData[i][j])<minValue) {
                minValue = abs(m_ppData[i][j]);
                minIndex = j;
            }
        }
    }

    return minIndex;
}
//// returns the minimum value in a row of the matrix
//int mkMatrix::GetRowMinIndex(int row) const
//{
//    // _ASSERT(row >= 0) ;
//    // _ASSERT(row < m_nRow) ;
//    double	value = GetElement(row,0) ;
//    int minIndex=0;
//    for (int i = 0 ; i < m_nCol ; ++i)
//        {
//        if (GetElement(row,i) < value)
//            value = GetElement(row,i) ;
//            minIndex = i;
//        }
//    return minIndex ;
//}
// returns the maximum value in a row of the matrix
double mkMatrix::GetRowMax(int row) const
{
    // _ASSERT(row >= 0) ;
    // _ASSERT(row < m_nRow) ;
    double	value = GetElement(row,0) ;
    for (int i = 0 ; i < m_nCol ; ++i)
        {
        if (GetElement(row,i) > value)
            value = GetElement(row,i) ;
        }
    return value ;
}
int mkMatrix::GetRowMaxIndex(int row) const
{
    // _ASSERT(row >= 0) ;
    // _ASSERT(row < m_nRow) ;
    double	value = GetElement(row,0) ;
    int index=0;
    for (int i = 0 ; i < m_nCol ; ++i)
    {
        if (GetElement(row,i) > value){
            value = GetElement(row,i) ;
            index = i;
        }
    }
    return index ;
}
// returns the minimum value in a column of the matrix
double mkMatrix::GetColumnMin(int column) const
{
    // _ASSERT(column >= 0) ;
    // _ASSERT(column < m_nCol) ;
    double	value = GetElement( 0,column) ;
    for (int i = 0 ; i < m_nRow ; ++i)
        {
        if (GetElement( i,column) < value)
            value = GetElement( i,column) ;
        }
    return value ;
}
int mkMatrix::GetColumnMinIndex(int column) const
{
    // _ASSERT(column >= 0) ;
    // _ASSERT(column < m_nCol) ;
    double	value = GetElement( 0,column) ;
    int index=0;
    for (int i = 0 ; i < m_nRow ; ++i)
        {
        if (GetElement( i,column) < value){
            value = GetElement( i,column) ;
            index = i;
        }
        }
    return index ;
}

// returns the maximum value in a column of the matrix
double mkMatrix::GetColumnMax(int column) const
{
    // _ASSERT(column >= 0) ;
    // _ASSERT(column < m_nCol) ;
    double	value = GetElement( 0,column) ;
    for (int i = 0 ; i < m_nRow ; ++i)
        {
        if (GetElement( i,column) > value)
            value = GetElement( i,column) ;
        }
    return value ;
}
int mkMatrix::GetColumnMaxIndex(int column) const
{
    // _ASSERT(column >= 0) ;
    // _ASSERT(column < m_nCol) ;
    double	value = GetElement( 0,column) ;
    int index = 0;
    for (int i = 0 ; i < m_nRow ; ++i)
    {
        if (GetElement( i,column) > value){
            value = GetElement( i,column) ;
            index = i;
        }
    }
    return value ;
}

//int mkMatrix::GetRowMaxIndex(int row) const
//{
//    // _ASSERT(row >= 0) ;
//    // _ASSERT(row < m_nRow) ;
//    int maxI=0;
//    double	value = m_ppData[row][0] ;
//    for (int i = 0 ; i < m_nCol ; ++i)
//    {
//        if (m_ppData[row][i] > value)
//        {
//            value = m_ppData[row][i];//GetElement(row,i) ;
//            maxI=i;
//        }
//    }
//    return maxI ;
//}

/* The routine "svdcmp" computes the singular value decomposition of a   */
/* matrix a. The result is in the form  a = u w v^t.                     */
/* The maxtix u replaces a on output. The diagonal matrix w              */
/* of singular values is output as a vector w[1..n]. The matrix v (not   */
/* the transposed v^t) is output as v[1..n][1..n]. m  must be greater or */
/* equal to n; if it is smaller, than a should be filled up to square    */
/* with zero rows.														 */
//#define SIGN(a,b) ((b) > 0.0 ? fabs(a) : -fabs(a))
static double sqrarg;
#define SQR(a) (( sqrarg = (a)) == 0.0 ? 0.0 : sqrarg * sqrarg)
static double maxarg1, maxarg2;
#define FMAX(a,b) (maxarg1=(a), maxarg2=(b), (maxarg1) > (maxarg2) ? \
(maxarg1) : (maxarg2))
static int iminarg1, iminarg2;
#define IMIN(a,b) (iminarg1=(a), iminarg2=(b),(iminarg1) < (iminarg2) ? \
(iminarg1) : (iminarg2))

double SIGN(double a,double b)
{
    double r=0.0;
    if(fabs(b)<0.0000000001)
        r= (-fabs(a));
    else
    {
        if(b>0.0)
            r=(	fabs(a));
        else
            r= (-fabs(a));
    }
//		TRACE("SIGN (%f,%f)=%f\n",a,b,r);

        return r;


}
double SIGN(double a)
{
    double r=0.0;
    if(fabs(a)<0.0000000001)
        r= -1.0;
    else
    {
        if(a>0.0)
            r=1.0;
        else
            r= -1.0;
    }
        return r;
}
double sign(double a)
{
    double r=0.0;
    if(fabs(a)<0.0000000001)
        r= -1.0;
    else
    {
        if(a>0.0)
            r=1.0;
        else
            r= -1.0;
    }
        return r;
}
static double PYTHAG(double a, double b)
{
    double at = fabs(a), bt = fabs(b), ct, result;

    if (at > bt)       { ct = bt / at; result = at * sqrt(1.0 + ct * ct); }
    else if (bt > 0.0) { ct = at / bt; result = bt * sqrt(1.0 + ct * ct); }
    else result = 0.0;
    return(result);
}

/*
 * svdcomp - SVD decomposition routine.
 * Takes an mxn matrix a and decomposes it into udv, where u,v are
 * left and right orthogonal transformation matrices, and d is a
 * diagonal matrix of singular values.
 *
 * This routine is adapted from svdecomp.c in XLISP-STAT 2.1 which is
 * code from Numerical Recipes adapted by Luke Tierney and David Betz.
 *
 * Input to dsvd is as follows:
 *   a = mxn matrix to be decomposed, gets overwritten with u
 *   m = row dimension of a
 *   n = column dimension of a
 *   w = returns the vector of singular values of a
 *   v = returns the right orthogonal transformation matrix
*/
int dsvd(double **a, int m, int n, double *w, double **v)
{
   int flag, i, its, j, jj, k, l, nm;
    double c, f, h, s, x, y, z;
    double anorm = 0.0, g = 0.0, scale = 0.0;
    double *rv1;



    rv1 = (double *)malloc((unsigned int) n*sizeof(double));

/* Householder reduction to bidiagonal form */
    for (i = 0; i < n; i++)
    {
        /* left-hand reduction */
        l = i + 1;
        rv1[i] = scale * g;
        g = s = scale = 0.0;
        if (i < m)
        {
            for (k = i; k < m; k++)
                scale += fabs((double)a[k][i]);
            if (scale)
            {
                for (k = i; k < m; k++)
                {
                    a[k][i] = (double)((double)a[k][i]/scale);
                    s += ((double)a[k][i] * (double)a[k][i]);
                }
                f = (double)a[i][i];
                g = -SIGN(sqrt(s), f);
                h = f * g - s;
                a[i][i] = (double)(f - g);
                if (i != n - 1)
                {
                    for (j = l; j < n; j++)
                    {
                        for (s = 0.0, k = i; k < m; k++)
                            s += ((double)a[k][i] * (double)a[k][j]);
                        f = s / h;
                        for (k = i; k < m; k++)
                            a[k][j] += (double)(f * (double)a[k][i]);
                    }
                }
                for (k = i; k < m; k++)
                    a[k][i] = (double)((double)a[k][i]*scale);
            }
        }
        w[i] = (double)(scale * g);

        /* right-hand reduction */
        g = s = scale = 0.0;
        if (i < m && i != n - 1)
        {
            for (k = l; k < n; k++)
                scale += fabs((double)a[i][k]);
            if (scale)
            {
                for (k = l; k < n; k++)
                {
                    a[i][k] = (double)((double)a[i][k]/scale);
                    s += ((double)a[i][k] * (double)a[i][k]);
                }
                f = (double)a[i][l];
                g = -SIGN(sqrt(s), f);
                h = f * g - s;
                a[i][l] = (double)(f - g);
                for (k = l; k < n; k++)
                    rv1[k] = (double)a[i][k] / h;
                if (i != m - 1)
                {
                    for (j = l; j < m; j++)
                    {
                        for (s = 0.0, k = l; k < n; k++)
                            s += ((double)a[j][k] * (double)a[i][k]);
                        for (k = l; k < n; k++)
                            a[j][k] += (double)(s * rv1[k]);
                    }
                }
                for (k = l; k < n; k++)
                    a[i][k] = (double)((double)a[i][k]*scale);
            }
        }
        anorm = FMAX(anorm, (fabs((double)w[i]) + fabs(rv1[i])));
    }

    /* accumulate the right-hand transformation */
    for (i = n - 1; i >= 0; i--)
    {
        if (i < n - 1)
        {
            if (g)
            {
                for (j = l; j < n; j++)
                    v[j][i] = (double)(((double)a[i][j] / (double)a[i][l]) / g);
                    /* double division to avoid underflow */
                for (j = l; j < n; j++)
                {
                    for (s = 0.0, k = l; k < n; k++)
                        s += ((double)a[i][k] * (double)v[k][j]);
                    for (k = l; k < n; k++)
                        v[k][j] += (double)(s * (double)v[k][i]);
                }
            }
            for (j = l; j < n; j++)
                v[i][j] = v[j][i] = 0.0;
        }
        v[i][i] = 1.0;
        g = rv1[i];
        l = i;
    }

    /* accumulate the left-hand transformation */
    for (i = n - 1; i >= 0; i--)
    {
        l = i + 1;
        g = (double)w[i];
        if (i < n - 1)
            for (j = l; j < n; j++)
                a[i][j] = 0.0;
        if (g)
        {
            g = 1.0 / g;
            if (i != n - 1)
            {
                for (j = l; j < n; j++)
                {
                    for (s = 0.0, k = l; k < m; k++)
                        s += ((double)a[k][i] * (double)a[k][j]);
                    f = (s / (double)a[i][i]) * g;
                    for (k = i; k < m; k++)
                        a[k][j] += (double)(f * (double)a[k][i]);
                }
            }
            for (j = i; j < m; j++)
                a[j][i] = (double)((double)a[j][i]*g);
        }
        else
        {
            for (j = i; j < m; j++)
                a[j][i] = 0.0;
        }
        ++a[i][i];
    }

    /* diagonalize the bidiagonal form */
    for (k = n - 1; k >= 0; k--)
    {                             /* loop over singular values */
        for (its = 0; its < 30; its++)
        {                         /* loop over allowed iterations */
            flag = 1;
            for (l = k; l >= 0; l--)
            {                     /* test for splitting */
                nm = l - 1;
                if (fabs(rv1[l]) + anorm == anorm)
                {
                    flag = 0;
                    break;
                }
                if (fabs((double)w[nm]) + anorm == anorm)
                    break;
            }
            if (flag)
            {
                c = 0.0;
                s = 1.0;
                for (i = l; i <= k; i++)
                {
                    f = s * rv1[i];
                    if (fabs(f) + anorm != anorm)
                    {
                        g = (double)w[i];
                        h = PYTHAG(f, g);
                        w[i] = (double)h;
                        h = 1.0 / h;
                        c = g * h;
                        s = (- f * h);
                        for (j = 0; j < m; j++)
                        {
                            y = (double)a[j][nm];
                            z = (double)a[j][i];
                            a[j][nm] = (double)(y * c + z * s);
                            a[j][i] = (double)(z * c - y * s);
                        }
                    }
                }
            }
            z = (double)w[k];
            if (l == k)
            {                  /* convergence */
                if (z < 0.0)
                {              /* make singular value nonnegative */
                    w[k] = (double)(-z);
                    for (j = 0; j < n; j++)
                        v[j][k] = (-v[j][k]);
                }
                break;
            }
            if (its >= 30) {
                free((void*) rv1);
                fprintf(stderr, "No convergence after 30,000! iterations \n");
                return 0;
            }

            /* shift from bottom 2 x 2 minor */
            x = (double)w[l];
            nm = k - 1;
            y = (double)w[nm];
            g = rv1[nm];
            h = rv1[k];
            f = ((y - z) * (y + z) + (g - h) * (g + h)) / (2.0 * h * y);
            g = PYTHAG(f, 1.0);
            f = ((x - z) * (x + z) + h * ((y / (f + SIGN(g, f))) - h)) / x;

            /* next QR transformation */
            c = s = 1.0;
            for (j = l; j <= nm; j++)
            {
                i = j + 1;
                g = rv1[i];
                y = (double)w[i];
                h = s * g;
                g = c * g;
                z = PYTHAG(f, h);
                rv1[j] = z;
                c = f / z;
                s = h / z;
                f = x * c + g * s;
                g = g * c - x * s;
                h = y * s;
                y = y * c;
                for (jj = 0; jj < n; jj++)
                {
                    x = (double)v[jj][j];
                    z = (double)v[jj][i];
                    v[jj][j] = (double)(x * c + z * s);
                    v[jj][i] = (double)(z * c - x * s);
                }
                z = PYTHAG(f, h);
                w[j] = (double)z;
                if (z)
                {
                    z = 1.0 / z;
                    c = f * z;
                    s = h * z;
                }
                f = (c * g) + (s * y);
                x = (c * y) - (s * g);
                for (jj = 0; jj < m; jj++)
                {
                    y = (double)a[jj][j];
                    z = (double)a[jj][i];
                    a[jj][j] = (double)(y * c + z * s);
                    a[jj][i] = (double)(z * c - y * s);
                }
            }
            rv1[l] = 0.0;
            rv1[k] = f;
            w[k] = (double)x;
        }
    }

    /* order the singular values */

    flag = 1;
    while(flag)	/* keep sorting until a complete pass with no swapping occurs */
    {
        flag = 0;
        for (i = 0; i < n-1; i++)
        {
            if (w[i] < w[i+1])
            {
                /* interchange i and (i+1) */
                rv1[0] = w[i+1];		/* interchange s */
                w[i+1] = w[i];
                w[i] = rv1[0];
                for (j = 0; j < m; j++)	/* interchange v columns */
                {
                    rv1[j] = v[j][i+1];
                    v[j][i+1] = v[j][i];
                    v[j][i] = rv1[j];
                }
                for (j = 0; j < m; j++)	/* interchange a columns */
                {
                    rv1[j] = a[j][i+1];
                    a[j][i+1] = a[j][i];
                    a[j][i] = rv1[j];
                }
                flag = 1;
            }


        }
    }
    int rank=0;
    for(i=0; i<n; i++)
    {
        if(w[i]>0.0000001)
            ++rank;
    }
    free((void*) rv1);
    return rank;
}


int compute_pseudo_inverse(int rw, int cw, double **Inv, double *N ,double **U, double *S, double**V)
{
    int h,i,j;
    int width_of_null_space;
    int k;
    int n;

    int Jacobian_Rank=0;
    int jacobian_height=rw;
    int jacobian_width=cw;

    double singularity_detection_radius=0.000001;
    double *work;



    /* Determine if a singularity exists by counting how many non-zero Sigmas there are in the SVD.
    ** If there is less than 6, than the manipulator is in a singularity.
    */

    /* Determine the rank of the Jacobian */

    j = 0;
    for (i = 0; i < MIN(jacobian_height,jacobian_width); i++)
    {
        if (S[i] > singularity_detection_radius)
            j++;
    }

    Jacobian_Rank = j;		/* Save the rank of the Jacobian */



    /* Set singularity flag for singularity Management */
/*
    j = 0;
    for (i = 0; i < min(jacobian_height,jacobian_width); i++)
    {
        if (Sigma[i] > parameters.singularity_management_radius)
            j++;
    }

    // count # of LOCKED POR DOFs
    k = 0;
    for (i = 0; i < number_of_branches; i++)
    {
        for (h = 0; h < 6; h++)
        {
            if (branch[i].por_locking[h] == LOCKED) k++;
        }
    }
    // If rank of jacobian is less then the # of commanded branches then raise singularity flag
    if (j < (number_of_branches*6-k-number_of_unconstrained_rows))
        singularity = TRUE;
    else
        singularity = FALSE;

    //                                 T
    //  Determine the determinant of JJ  which is needed for singularity avoidance
    //

    //                                         2
    // Potential Function V = (s1 * s2 * s3 ...)
    //

    det_J_JT = (double)1.0;

    for (i = 0; i < min(jacobian_height,jacobian_width); i++)
        det_J_JT *= (double)(Sigma[i] * Sigma[i]);
*/
    /* Compute pseudo-inverse and null space matrix for the manipulator */

    n = jacobian_width;
    k = Jacobian_Rank;

    width_of_null_space = MAX(0,jacobian_width - Jacobian_Rank);

    /* Partition the U and V matrices  */
    /*
    **   U1 = Umatrix(:,1:k)
    **   V1 = Vmatrix(:,1:k)
    **   NULL SPACE = Vmatrix(:,k+1:N)
    */
    if(Jacobian_Rank<1)
        return 0;
    if(N!=NULL)
    {

        for (i = 0 ; i < n; i++)
        {
            for (j = k; j < n; j++)
                N[i*width_of_null_space+(j-k)] = (double) V[i][j];	// Figure out null space matrix
        }
    }


    /* Compute the pseudo-inverse of the Jacobian */
    /*   +                                            T
    **	J  = V1 . diag(1/sigma_1 , ... 1/sigma_k) . U1
    */

    /* First we do diag(1/sigma_1,...1/sigma_k) . U1T */
    work = (double *)malloc(sizeof(double)*k*jacobian_height);

    for (i = 0; i < k; i++)
    {
        for (j = 0; j < jacobian_height; j++)
        {
            work[i*jacobian_height+j] = (double) (1.0/S[i]) * U[j][i];	/*NOTE The transpose of U is being used */
        }
    }

    /* Now we do J+ = V1 . work */

    for (h = 0; h < n; h++)
    {
        for (i = 0; i < jacobian_height; i++)
        {
            Inv[h][i] = 0.0;

            for (j = 0; j < k; j++)
                Inv[h][i] += (double) V[h][j] * work[j*jacobian_height+i];
        }
    }

    free(work);
    return Jacobian_Rank;
}



void eig(mkMatrix &In, mkMatrix &eig_Value, mkMatrix &eig_Vector)
{
    int n=In.GetNumRows();
    mkMatrix e(1,n);
    //eig_Value.Zeros(1,n);
    //eig_Vector.Zeros(n,n);


    tred2(In.m_ppData,n,eig_Value.m_pData, e.m_pData);
    //printMat("In",In);


    eig_Vector=In;
    tqli(eig_Value.m_pData,e.m_pData,n,eig_Vector.m_ppData);
    //printMat("eig_Vector",eig_Vector);
}
void tred2(double **a, int n, double d[], double e[])
{
    int l,k,j,i;
    double  scale,hh,h,g,f;
    ////////////////////////////////
    for (i = 0; i < n; ++i)
             (a[i])--;
    a--;
    d--;
    e--;
    ///////////////////////////////

 for (i = n; i >= 2; i--)
     {
         l = i - 1;
         h = scale = 0.0;
         if (l > 1)
         {
             for (k = 1; k <= l; k++)
                 scale += abs(a[i][k]);
             if (scale == 0.0)
                 e[i] = a[i][l];
             else
             {
                 for (k = 1; k <= l; k++)
                 {
                     a[i][k] /= scale;
                     h += a[i][k] * a[i][k];
                 }
                 f = a[i][l];
                 g = f > 0 ? -sqrt(h) : sqrt(h);
                 e[i] = scale * g;
                 h -= f * g;
                 a[i][l] = f - g;
                 f = 0.0;
                 for (j = 1; j <= l; j++)
                 {
                     a[j][i] = a[i][j] / h;
                     g = 0.0;
                     for (k = 1; k <= j; k++)
                         g += a[j][k] * a[i][k];
                     for (k = j + 1; k <= l; k++)
                         g += a[k][j] * a[i][k];
                     e[j] = g / h;
                     f += e[j] * a[i][j];
                 }
                 hh = f / (h + h);
                 for (j = 1; j <= l; j++)
                 {
                     f = a[i][j];
                     e[j] = g = e[j] - hh * f;
                     for (k = 1; k <= j; k++)
                         a[j][k] -= (f * e[k] + g * a[i][k]);
                 }
             }
         } else
             e[i] = a[i][l];
         d[i] = h;
     }
     d[1] = 0.0;
     e[1] = 0.0;
     for (i = 1; i <= n; i++)
     {
         l = i - 1;
         if (d[i])
         {
             for (j = 1; j <= l; j++)
             {
                 g = 0.0;
                 for (k = 1; k <= l; k++)
                     g += a[i][k] * a[k][j];
                 for (k = 1; k <= l; k++)
                     a[k][j] -= g * a[k][i];
             }
         }
         d[i] = a[i][i];
         a[i][i] = 1.0;
         for (j = 1; j <= l; j++)
             a[j][i] = a[i][j] = 0.0;
     }


    //////////////////////////////////////
    a++;
    d++;
    e++;
    for (i = 0; i < n; ++i)
        (a[i])++;
    /////////////////////////////////////

}

void tqli(double d[], double e[], int n, double **z)
 {
   // QL algorithm with implicit shifts, to determine the eigenvalues and eigenvectors of a real, sym-
// metric, tridiagonal matrix, or of a real, symmetric matrix previously reduced by tred2 x 11.2. On
// input, d[1..n] contains the diagonal elements of the tridiagonal matrix. On output, it returns
// the eigenvalues. The vector e[1..n] inputs the subdiagonal elements of the tridiagonal matrix,
// with e[1] arbitrary. On output e is destroyed. When finding only the eigenvalues, several lines
// may be omitted, as noted in the comments. If the eigenvectors of a tridiagonal matrix are de-
// sired, the matrix z[1..n][1..n] is input as the identity matrix. If the eigenvectors of a matrix
// that has been reduced by tred2 are required, then z is input as the matrix output by tred2.
// In either case, the kth column of z returns the normalized eigenvector corresponding to d[k].

   int m,l,iter,i,k;
   double s,r,p,g,f,dd,c,b;

   //////////////////////////////
    for (i = 0; i < n; ++i)
         (z[i])--;
    z--;
    d--;
    e--;
   //////////////////////////////

     for (i = 2; i <= n; i++)
         e[i - 1] = e[i];
     e[n] = 0.0;
     for (l = 1; l <= n; l++)
     {
         iter = 0;
         do
         {
             for (m = l; m <= n - 1; m++)
             {
                 dd = abs(d[m]) + abs(d[m + 1]);
                 if (abs(e[m]) + dd == dd)
                     break;
             }
             if (m != l)
             {
                 if (iter++ == 30)
                     return ;
                 g = (d[l + 1] - d[l]) / (2.0 * e[l]);
                 r = sqrt((g * g) + 1.0);
                 g = d[m] - d[l] + e[l] / (g + SIGN(r, g));
                 s = c = 1.0;
                 p = 0.0;
                 for (i = m - 1; i >= l; i--)
                 {
                     f = s * e[i];
                     b = c * e[i];
                     if (abs(f) >= abs(g))
                     {
                         c = g / f;
                         r = sqrt((c * c) + 1.0);
                         e[i + 1] = f * r;
                         c *= (s = 1.0 / r);
                     } else
                     {
                         s = f / g;
                         r = sqrt((s * s) + 1.0);
                         e[i + 1] = g * r;
                         s *= (c = 1.0 / r);
                     }
                     g = d[i + 1] - p;
                     r = (d[i] - g) * s + 2.0 * c * b;
                     p = s * r;
                     d[i + 1] = g + p;
                     g = c * r - b;
                     for (k = 1; k <= n; k++)
                     {
                         f = z[k][i + 1];
                         z[k][i + 1] = s * z[k][i] + c * f;
                         z[k][i] = c * z[k][i] - s * f;
                     }
                 }
                 d[l] = d[l] - p;
                 e[l] = g;
                 e[m] = 0.0;
             }
         } while (m != l);
     }

   ///////////////////////////////////////
    z++;
    d++;
    e++;
    for (i = 0; i < n; ++i)
     (z[i])++;
   ////////////////////////////////////

 }


void mkMatrix::Eye(int size)
{
        DecrementAndRelease();
        m_nCol = size ;
        m_nRow = size ;
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        for(int i=0; i<size; i++)
        {
            m_ppData[i][i]=1.0;
        }
        IncrementReferenceCount() ;
}
void mkMatrix::Eye(int size, double val)
{
        DecrementAndRelease();
        m_nCol = size ;
        m_nRow = size ;
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        for(int i=0; i<size; i++)
        {
            m_ppData[i][i]=val;
        }
        IncrementReferenceCount() ;
}
void mkMatrix::SetEye(double val)
{

        int size = m_nRow ;

        for(int i=0; i<size; i++)
        {
            m_ppData[i][i]=val;
        }

}

mkMatrix mkMatrix::Inverse()
{
    mkMatrix U, invS, V, inv;
    double *W= new double[m_nRow];
    U = *this;
    invS.Zeros(m_nRow, m_nCol);
    V.Zeros(m_nRow, m_nCol);
    dsvd(U.m_ppData, m_nRow, m_nCol,W, V.m_ppData);
    for(int i=0; i<m_nRow; i++)
    {
        invS.m_ppData[i][i] = 1.0/W[i];
    }
    delete [] W;
//    printMat("U: ", U);
//    printMat("V: ", V);
//    printMat("invS: ", invS);


    //V*inv(S)*U'
    return V*invS*U.GetTransposed();
}

mkMatrix mkMatrix::getRow(int index)
{
    mkMatrix row(1,m_nRow);
    for(int i=0; i<m_nRow; i++) {
        row.m_pData[i] = m_ppData[index][i];
    }
    return row;
}

mkMatrix mkMatrix::getCol(int index)
{
    mkMatrix col(1,m_nCol);
    for(int i=0; i<m_nCol; i++) {
        col.m_pData[i] = m_ppData[i][index];
    }
    return col;
}

void mkMatrix::Diag(int size, double *vec)
{
        DecrementAndRelease();
        m_nCol = size ;
        m_nRow = size ;
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        for(int i=0; i<size; i++)
        {
            m_ppData[i][i]=vec[i];
        }
        IncrementReferenceCount() ;
}

void mkMatrix::Zeros(int rw, int cw)
{
        DecrementAndRelease();
        m_nCol = cw ;
        m_nRow = rw ;
        m_pData = AllocateMemory(m_nRow, m_nCol ) ;
        m_ppData = Make2Dim(m_pData, m_nRow, m_nCol ) ;
        IncrementReferenceCount() ;
}

void mkMatrix::Reset(double val)
{
    int total=m_nCol*m_nRow;
    memset(m_pData,(int)val,sizeof(double)*total);
    //for(int i=0; i<total; i++)
    //	m_pData[i]=val;
}
/////////////////////////////////////////
// Get sub matrix
mkMatrix mkMatrix::GetElements(int sRow,int nRow, int sCol, int nCol)const
{

    // _ASSERT(sCol >= 0) ;							// array bounds error
    // _ASSERT(nCol <= m_nCol) ;						// array bounds error
    // _ASSERT(sRow >= 0) ;							// array bounds error
    // _ASSERT(nRow <= m_nRow) ;						// array bounds error
    // _ASSERT(m_pData) ;							// bad pointer error
    // _ASSERT(sRow<=nRow);
    // _ASSERT(sCol<=nCol);

    int row=nRow-sRow;
    int col=nCol-sCol;
    mkMatrix Out(row+1,col+1);
    for(int m=0; m<=row; m++)
    {
        memcpy((double *)Out.m_ppData[m],(double *)(this->m_ppData[m+sRow]+sCol),sizeof(double)*(col+1));
    }
    //Out.ExtractSubMatrix
    return Out;
}
void mkMatrix::SetElements(int sRow,int sCol, const mkMatrix & In)
{
    int row=In.GetNumRows();
    int col=In.GetNumColumns();

    // _ASSERT(sRow<m_nRow);
    // _ASSERT(sCol<m_nCol);
    // _ASSERT(sCol+col <= m_nCol) ;						// array bounds error
    // _ASSERT(sRow+row <=m_nRow ) ;							// array bounds error

    for(int m=sRow; m<sRow+row; m++)
    {
        memcpy((double *)(this->m_ppData[m]+sCol),(double *)In.m_ppData[m-sRow],sizeof(double)*(col));
    }

}
mkMatrix mkMatrix::Mean()
{
    int row =this->GetNumRows();
    int col = this->GetNumColumns();
    mkMatrix Out(1,col);
    int i,j;
    double sum=0.0;
    for(j=0; j<col; j++)
    {
        sum=0.0;
        for(i=0; i<row; i++)
        {
            sum+=this->m_ppData[i][j];
        }
        Out.m_ppData[0][j]=sum/row;
    }
    return Out;
}
double mkMatrix::Trace()
{
    double sum=0.0;
    int r=this->GetNumRows();
    int c=this->GetNumColumns();
    int i,n;
    (r<=c)?n=r:n=c;

    for(i=0; i<n; i++)
    {
        sum+=this->m_ppData[i][i];
    }
    return sum;
}
int mkMatrix::getMaxLen()
{
    int max=0;
    (m_nRow<m_nCol)? max=m_nCol: max=m_nRow;
    return max;
}
////////////////////////////////////////////////////////////////////////

mkMatrix Cross(const mkMatrix &A, const mkMatrix &B)
{
    mkMatrix C(1,3);
    //% Calculate cross product
    C.m_pData[0]= A.m_pData[1]*B.m_pData[2] - A.m_pData[2]*B.m_pData[1];
    C.m_pData[1]= A.m_pData[2]*B.m_pData[0] - A.m_pData[0]*B.m_pData[2];
    C.m_pData[2]= A.m_pData[0]*B.m_pData[1] - A.m_pData[1]*B.m_pData[0];
    return C;
}
double Dot(const mkMatrix &A, const mkMatrix &B)
{
    return (A.m_pData[0]*B.m_pData[0] + A.m_pData[1]*B.m_pData[1] + A.m_pData[2]*B.m_pData[2]);
}
double Norm(const mkMatrix &mat, int m2)
{
    int r = mat.GetNumRows();
    int c = mat.GetNumColumns();
    int i, total=r*c;
    double sum =0.0;
    for(i=0;i<total; i++)
    {
            sum +=mat.m_pData[i]*mat.m_pData[i];
    }

    if(m2==1) return (sqrt(sum));
    else return (sum);

}
void Normalize(double mat[])
{

    double sum =0.0, s;
    for(int i=0;i<3; i++)
    {
            sum +=mat[i]*mat[i];
    }
    if(abs(sum)<1.0e-10) return;

    s=sqrt(sum);
    for(int i=0;i<3; i++)
    {
            mat[i]=mat[i]/s;
    }


}


void Matching(const mkMatrix &Tp, const mkMatrix &Cp,  mkMatrix &matchedPoint)
{
    int m,n;
    int nCp = Cp.GetNumRows();
    int nTp = Tp.GetNumRows();
    double dis = 0.f;
    int closest_index=0;
    double min_dis=1000000000.0;
    //printMat("Tp",Tp);
    //printMat("Cp",Cp);
    matchedPoint.Zeros(nCp,Cp.GetNumColumns());//same size of Cp
    for(m=0;m<nCp;m++)
    {
        closest_index=0;
        min_dis=1000000000.0;
        for(n=0;n<nTp;n++)
        {
            dis = Norm(Tp.GetElements(n,n,0,2)-Cp.GetElements(m,m,0,2));
            if(dis<min_dis)
            {
                min_dis=dis;
                closest_index = n;
            }
        }// end of for(n)...
        memcpy((double*)matchedPoint.m_ppData[m],(double*)Tp.m_ppData[closest_index],sizeof(double)*3);
        //printMat("Matching",matchedPoint);
        //printf("Matching[%d] %f, %f, %f \n",m, matchedPoint.m_ppData[m][0],matchedPoint.m_ppData[m][1],matchedPoint.m_ppData[m][2]);
    }// end of for(m)...
    //g_log << message << std::endl;
}

/////////////////////////////////////////////////////
bool rot2euler(mkMatrix &in_rot, double out_euler3[], bool isRad)
{
//    function [rx, ry, rz]=rot2euler(Rot)
//    %% rotation order: xyz
//    % Mike Kim
//    if( abs(Rot(1,3)-1)<1.0e-6)
//        %// Not a uniquesolution : thetaZ + thetaX = atan2 ( r21 , r22 )
//        ry = pi/2;%+PI / 2;
//        rx = atan2(Rot(2,1), Rot(2,2));%a t a n 2 ( r10 , r 1 1 ) ;
//        rz = 0 ;
//    else
//        if(abs(Rot(1,3)+1)<1.0e-6)
//            %Not unique solution
//            ry = -pi/2;
//            rx = -atan2(Rot(2,1), Rot(2,2));
//            rz = 0 ;
//        else
//            ry = asin ( Rot(1,3) ) ;
//            rx = atan2(-Rot(2,3), Rot(3,3));
//            rz = atan2(-Rot(1,2), Rot(1,1));
//        end
//    end
    if(in_rot.m_nCol<2 || in_rot.m_nRow <2 ) return false;
    if(out_euler3==nullptr) return false;

    if( abs(in_rot.m_ppData[0][2]-1.0)<1.0e-6) {
        out_euler3[1] = PI/2.0;
        out_euler3[0] = atan2(in_rot.m_ppData[1][0], in_rot.m_ppData[1][1]);
        out_euler3[2] = 0.0;
    }
    else if(abs(in_rot.m_ppData[0][2]+1.0)<1.0e-6) {
        //Not unique solution
        out_euler3[1] = -PI/2.0;
        out_euler3[0] = -atan2(in_rot.m_ppData[1][0], in_rot.m_ppData[1][1]);
        out_euler3[2] = 0.0;
    }
    else {
        out_euler3[1] = asin(in_rot.m_ppData[0][2]);
        out_euler3[0] = atan2(-in_rot.m_ppData[1][2], in_rot.m_ppData[2][2]);
        out_euler3[2] = atan2(-in_rot.m_ppData[0][1], in_rot.m_ppData[0][0]);
    }
    if(isRad==false) {
        for(int i=0; i<3; i++)
            out_euler3[i] = out_euler3[i]*RTOD;//RAD2DEG(out_euler3[i]);
    }
    return true;
}

void euler_axis_angle(const mkMatrix &R1, mkMatrix &u, double &phi)//function [u, phi] = euler_axis_angle(R)
{
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%% File: euler_axis_angle.m
//%% Aurthor: Mike Kim
//%% Date: Nov. 22, 2004
//%% -----------------------------------------------------------------
//%% Description: This function computes the axis angle representation of a given
//%%              rotation matrix R.
//%%
//%% Input:
//%% 	real R[3][3]
//%%
//%% Outputs:
//%%		real u[3x1], phi
//%%	,where
//%%		u = the eigenvector of u corresponding to the unity
//%%		    eigenvalue
//%%
//%%		phi = the angle
//%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     double TINY = 1.0E-7, c,s;
     mkMatrix R;

     u.Zeros(3,1);
     R=R1.GetTransposed();

     u.m_pData[0] = R.m_ppData[1][2]-R.m_ppData[2][1]; //u(1) = R(2,3)-R(3,2);
     u.m_pData[1] = R.m_ppData[2][0]-R.m_ppData[0][2]; //u(2) = R(3,1)-R(1,3);
     u.m_pData[2] = R.m_ppData[0][1]-R.m_ppData[1][0]; //u(3) = R(1,2)-R(2,1);

     c = R.Trace() - 1.0; //c = R(1,1) + R(2,2) + R(3,3)-1.0;
     s = Norm(u);
     if(c > 1.41421356)
     {
         if(s < TINY){
            phi = 0.0;
            u.Reset(0.0); //u = zeros(3,1);
            }
         else{
             u = u/s;
                //u(1) = u(1) / s;
                //u(2) = u(2) / s;
                //u(3) = u(3) / s;
            phi = asin(s*0.5);
         }
     }
     else if(c < -1.41421356)
     {
        if(s < TINY)//////////////////////////////////////////////////////////
        {
            phi = PI;
            /////////////////////////////////////
            if(R.m_ppData[0][0]> R.m_ppData[1][1]) //if(R(1,1) > R(2,2))
            {
                if(R.m_ppData[0][0]>R.m_ppData[2][2]) //if(R(1,1) > R(3,3))
                {
                    //%% R(1,1) is greatest
                    u.m_pData[0] = R.m_ppData[0][0] + 1.0;  //u(1) = R(1,1) + 1.0;
                    u.m_pData[1] = R.m_ppData[1][0];        //u(2) = R(2,1);
                    u.m_pData[2] = R.m_ppData[2][0];        //u(3) = R(3,1);
                }
                else
                {
                    //%% R(3,3) is greatest
                    u.m_pData[0] = R.m_ppData[0][2];       //u(1) = R(1,3);
                    u.m_pData[1] = R.m_ppData[1][2];       //u(2) = R(2,3);
                    u.m_pData[2] = R.m_ppData[2][2] + 1.0; //u(3) = R(3,3) + 1.0;
                }
            }// end of if(R(1,1) > R(2,2))...
            else
            {
                if(R.m_ppData[1][1]>R.m_ppData[2][2]) //if(R(2,2) > R(3,3))
                {
                    //%% R(2,2) is greatest
                    u.m_pData[0] = R.m_ppData[0][1];       //u(1) = R(1,2);
                    u.m_pData[1] = R.m_ppData[1][1] + 1.0; //u(2) = R(2,2) + 1.0;
                    u.m_pData[2] = R.m_ppData[2][1];       //u(3) = R(3,2);
                }
                else
                {
                    //%% R(3,3) is greatest
                    u.m_pData[0] = R.m_ppData[0][2]; //u(1) = R(1,3);
                    u.m_pData[1] = R.m_ppData[1][2]; //u(2) = R(2,3);
                    u.m_pData[2] = R.m_ppData[2][2] + 1.0; //u(3) = R(3,3) + 1.0;
                }
            }// end of else...
            ///////////////////////////////////////
            s = Norm(u);
            u = u/s;
                //u(1) = u(1) / s;
                //u(2) = u(2) / s;
                //u(3) = u(3) / s;
        }////////////////////////////////////////////////////////////////////////
        else
        {
            u = u/s;
                //u(1) = u(1) / s;
                //u(2) = u(2) / s;
                //u(3) = u(3) / s;
            phi = PI-asin(s*0.5);
        } //if (s < TINY)
     }
     else
     {
          phi = acos(c*0.5);
          u = u/s;
              //u(1) = u(1) / s;
              //u(2) = u(2) / s;
              //u(3) = u(3) / s;
     } //%if(c > 1.41421356),
}
/////////////////////////////////////////////////////

void printMat(const char *name, mkMatrix &mat)
{
    int row=mat.GetNumRows();
    int col=mat.GetNumColumns();
    int i,j;
    qDebug("\nMatrix Name: %s [%dx%d]",name, row,col);
    std::string str;
    char data[528];
    for(i=0; i<row; i++)
    {
        for(j=0; j<col; j++)
        {
            sprintf(data,"%3.4f ",mat.m_ppData[i][j]);
            str +=data;
            //qDebug("%6.10f, ",mat.m_ppData[i][j]);
           // qDebug().nospace().noquote() << mat.m_ppData[i][j];
           // qDebug( "the integer is: %d", 12345 );
        }

  //    qDebug()<<"";
        qDebug( "%s;", str.c_str() );
        str="";
    }
}
void fprintMat(char *name, mkMatrix &mat)
{
        FILE *pf;
    /////////////////////////////////////////
    // ++ save pickdata
    pf = fopen(name,"wt");
    int row=mat.GetNumRows();
    int col=mat.GetNumColumns();
    int i,j;
    fprintf(pf,"\nMatrix Name: %s [%dx%d]\n",name, row,col);
    for(i=0; i<row; i++)
    {
        for(j=0; j<col; j++)
        {
            fprintf(pf,"%6.5f, ",mat.m_ppData[i][j]);
        }
        fprintf(pf,"\n");
    }
    fclose(pf);
}

mkMatrix traXYZ(double x, double y, double z)
{
    mkMatrix mat;
    mat.Eye(4,1.0);
    mat.m_ppData[0][3] = x;
    mat.m_ppData[1][3] = y;
    mat.m_ppData[2][3] = z;

    return mat;

}
mkMatrix rotX( double deg)
{
    mkMatrix mat;
    mat.Zeros(4,4);
    double rad = deg*DTOR;//DEG2RAD(deg);
    double C=cos(rad);
    double S=sin(rad);

//    mat4x4(1,1)= 1;
//    mat4x4(2,2) = cos(rad);
//    mat4x4(2,3) = -sin(rad);
//    mat4x4(3,2) = sin(rad);
//    mat4x4(3,3) = cos(rad);
//    mat4x4(4,4) = 1;

    mat.m_ppData[0][0] = 1.0;
    mat.m_ppData[1][1] = C;
    mat.m_ppData[1][2] = -S;
    mat.m_ppData[2][1] = S;
    mat.m_ppData[2][2] = C;
    mat.m_ppData[3][3] = 1.0;

    return mat;
}
mkMatrix rotY( double deg)
{
    mkMatrix mat;
    mat.Zeros(4,4);
    double rad = deg*DTOR;//DEG2RAD(deg);
    double C=cos(rad);
    double S=sin(rad);

//    mat4x4(1,1)= cos(rad);
//    mat4x4(1,3) = sin(rad);
//    mat4x4(2,2) = 1.0;
//    mat4x4(3,1) = -sin(rad);
//    mat4x4(3,3) = cos(rad);
//    mat4x4(4,4) = 1;

    mat.m_ppData[0][0] = C;
    mat.m_ppData[0][2] = S;
    mat.m_ppData[1][1] = 1.0;
    mat.m_ppData[2][0] = -S;
    mat.m_ppData[2][2] = C;
    mat.m_ppData[3][3] = 1.0;

    return mat;
}
mkMatrix rotZ( double deg)
{
    mkMatrix mat;
    mat.Zeros(4,4);
    double rad = deg*DTOR;//DEG2RAD(deg);
    double C=cos(rad);
    double S=sin(rad);


    mat.m_ppData[0][0] = C;
    mat.m_ppData[0][1] = -S;
    mat.m_ppData[1][0] = S;
    mat.m_ppData[1][1] = C;
    mat.m_ppData[2][2] = 1.0;
    mat.m_ppData[3][3] = 1.0;

    return mat;
}
mkMatrix rotXrad( double rad)
{
    mkMatrix mat;
    mat.Zeros(4,4);
    double C=cos(rad);
    double S=sin(rad);

//    mat4x4(1,1)= 1;
//    mat4x4(2,2) = cos(rad);
//    mat4x4(2,3) = -sin(rad);
//    mat4x4(3,2) = sin(rad);
//    mat4x4(3,3) = cos(rad);
//    mat4x4(4,4) = 1;

    mat.m_ppData[0][0] = 1.0;
    mat.m_ppData[1][1] = C;
    mat.m_ppData[1][2] = -S;
    mat.m_ppData[2][1] = S;
    mat.m_ppData[2][2] = C;
    mat.m_ppData[3][3] = 1.0;

    return mat;
}
mkMatrix rotYrad( double rad)
{
    mkMatrix mat;
    mat.Zeros(4,4);
    double C=cos(rad);
    double S=sin(rad);

//    mat4x4(1,1)= cos(rad);
//    mat4x4(1,3) = sin(rad);
//    mat4x4(2,2) = 1.0;
//    mat4x4(3,1) = -sin(rad);
//    mat4x4(3,3) = cos(rad);
//    mat4x4(4,4) = 1;

    mat.m_ppData[0][0] = C;
    mat.m_ppData[0][2] = S;
    mat.m_ppData[1][1] = 1.0;
    mat.m_ppData[2][0] = -S;
    mat.m_ppData[2][2] = C;
    mat.m_ppData[3][3] = 1.0;

    return mat;
}
mkMatrix rotZrad( double rad)
{
    mkMatrix mat;
    mat.Zeros(4,4);

    double C=cos(rad);
    double S=sin(rad);


    mat.m_ppData[0][0] = C;
    mat.m_ppData[0][1] = -S;
    mat.m_ppData[1][0] = S;
    mat.m_ppData[1][1] = C;
    mat.m_ppData[2][2] = 1.0;
    mat.m_ppData[3][3] = 1.0;

    return mat;
}

mkMatrix tild(double v0, double v1, double v2)
{
    double v[3] = {v0, v1, v2};
    return tild(v);
}

mkMatrix tild(double v[])
{
    mkMatrix mat(3,3);
    mat.m_ppData[0][1] = -v[2];
    mat.m_ppData[1][0] =  v[2];

    mat.m_ppData[0][2] =  v[1];
    mat.m_ppData[2][0] = -v[1];

    mat.m_ppData[1][2] = -v[0];
    mat.m_ppData[2][1] =  v[0];

    return mat;

//    R= [ 0   -v(3) v(2);
//        v(3) 0    -v(1);
//        -v(2) v(1) 0;];
}

mkMatrix rotX3(double rad)
{
    mkMatrix mat(3,3);
    double C=cos(rad);
    double S=sin(rad);
    mat.m_ppData[0][0] = 1.0;
    mat.m_ppData[1][1] = C;
    mat.m_ppData[1][2] = -S;
    mat.m_ppData[2][1] = S;
    mat.m_ppData[2][2] = C;
    return mat;
}

mkMatrix rotY3(double rad)
{
    mkMatrix mat(3,3);
    double C=cos(rad);
    double S=sin(rad);

    mat.m_ppData[0][0] = C;
    mat.m_ppData[0][2] = S;
    mat.m_ppData[1][1] = 1.0;
    mat.m_ppData[2][0] = -S;
    mat.m_ppData[2][2] = C;

    return mat;
}

mkMatrix rotZ3(double rad)
{
    mkMatrix mat(3,3);
    double C=cos(rad);
    double S=sin(rad);

    mat.m_ppData[0][0] = C;
    mat.m_ppData[0][1] = -S;
    mat.m_ppData[1][0] = S;
    mat.m_ppData[1][1] = C;
    mat.m_ppData[2][2] = 1.0;
    return mat;
}

void Cross(double A[], double B[], double C[])
{
    //% Calculate cross product
    C[0]= A[1]*B[2] - A[2]*B[1];
    C[1]= A[2]*B[0] - A[0]*B[2];
    C[2]= A[0]*B[1] - A[1]*B[0];
}
