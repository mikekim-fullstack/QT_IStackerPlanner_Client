#ifndef MKRINGBUFFER_H
#define MKRINGBUFFER_H
#include <string>
#include <iostream>

#ifndef MK_BUFSIZE
    #define MK_BUFSIZE 128
#endif

#ifndef MK_MAX_CMD_SIZE
    #define MK_MAX_CMD_SIZE 128
#endif
class mkRingBuffer
{

public:
    char curBuffer[128];

    bool bErrorOccered = false; // When the error occured, resend it in write funcion.
    char backupBuffer[128];// when there is error recieved, it can be resent.


    char cmdbuffer[MK_BUFSIZE][MK_MAX_CMD_SIZE]={{0}};
    char *strchr_pointer=0;
    int count=0, buflen=0;
    int bufindw = 0, bufindr = 0;
    bool igotFirstMessage=false;
    bool bReadyToWrite=false;// To syncronize response and write function


public:
    mkRingBuffer() {

    }
public:
    void write(char * data) {
        size_t len = strlen(data);
        memcpy(cmdbuffer[bufindw],data,len);

        memcpy(backupBuffer,data,len);
        backupBuffer[len] = 0;

        memcpy(curBuffer,data,len);
        curBuffer[len] = 0;
        cmdbuffer[bufindw][len] = 0;
        bufindw = (bufindw + 1)%MK_BUFSIZE;
        buflen += 1;
        count = 0;
    }
    void write(char * data, int len) {
        memcpy(cmdbuffer[bufindw],data,len);
        memcpy(curBuffer,data,len);

        curBuffer[len] = 0;

        memcpy(backupBuffer,data,len);
        backupBuffer[len] = 0;

        cmdbuffer[bufindw][len] = 0;
        bufindw = (bufindw + 1)%MK_BUFSIZE;
        buflen += 1;
        count = 0;
    }

//    void read(char *outData) {
//        if(outData==0) return;
//        memcpy(outData, cmdbuffer[bufindw],getLengthStr());
//        buflen = (buflen - 1);
//        bufindr = (bufindr + 1) % MK_BUFSIZE;
//    }
    void readDone() {
        buflen = (buflen - 1);
        bufindr = (bufindr + 1) % MK_BUFSIZE;
    }
    char * getCmd() {
        return cmdbuffer[bufindr];
    }
    size_t getLengthStr() {
        return strlen(cmdbuffer[bufindr]);
    }
    bool isEmpty() {
        if(buflen<=0) return true;
        return false;
    }
//    bool codeSeen(char code) {
//        strchr_pointer = strchr(cmdbuffer[bufindr], code);
//        return (strchr_pointer != nullptr);
//    }
    int codeSeen(char code) {
        strchr_pointer = strchr(cmdbuffer[bufindr], code);
        if(strchr_pointer == nullptr) return 0;

        int index = strlen(cmdbuffer[bufindr])-strlen(strchr_pointer)+1;
        return index;

    }
    double codeValue() {
        return (strtod(&cmdbuffer[bufindr][strchr_pointer - cmdbuffer[bufindr] + 1], nullptr));
    }
    void reset() {
         count=0; buflen=0;
         bufindw = 0; bufindr = 0;
         igotFirstMessage=false;
         strchr_pointer=0;
         memset(cmdbuffer, 0, sizeof(char)*MK_BUFSIZE*MK_MAX_CMD_SIZE);
    }
    void print() {
        std::cout<<"buffered data = \033[1;36m"<< curBuffer<<"\033[0m"<<std::endl<<std::flush;
    }

};

#endif // MKRINGBUFFER_H
