#ifndef MKMATRIX_H
#define MKMATRIX_H
#define _USE_MATH_DEFINES
#include <math.h>
#include <string.h>
#include <time.h>
#define PI  M_PI
#define PI2 M_PI*2.0
#define PIHALF M_PI_2

#define DTOR  0.01745329251994329576// M_PI/180.0// //convert degrees to radians
#define RTOD  57.29577951308232087684//180.0/M_PI//; //convert radians to degrees



//#define DEG2RAD(fTheta)     ((fTheta)*M_PI/180.0)
//#define RAD2DEG(fRad)       ((fRad)*180.0/M_PI)

#define UNUSED_PARAMETER(x) x

//#define	COND2R	(double)(PI/180.0)
//#define CONR2D	(double)(180.0/PI)

/*
** SVD DATA STRUCTURE
*/
double SIGN(double a,double b);
//double pythag(double a, double b);
//void svdcmp(double **a, int m, int n, double *w, double **v);
int compute_pseudo_inverse(int rw, int cw, double **Inv,double *N, double **U, double *S, double**V);
int dsvd(double **a, int m, int n, double *w, double **v);// return rank


class mkMatrix //: public CObject
{
public:
    //DECLARE_SERIAL(mkMatrix) ;
    // internal variables
    int m_nRow; // number of rows in matrix
    int m_nCol; // number of columns in matrix
    double* m_pData; // pointer to data, may be shared among objects
    double**        m_ppData;
#ifdef _DEBUG
    // variables used in debug for obejct counting
    static int		m_NextObjectNumber ;
    int				m_ObjectNumber ;
#endif
public:
    bool m_bNULL;
    void CopyData(int rs, int cs,int rw, int cw, double *pData);
    friend class	mkMatrixHelper ;						// used for operator[][]
    // construction and destruction
                    mkMatrix(int r, int c, double * pData);
                    mkMatrix() ;							// default constructor
                    mkMatrix(const mkMatrix &other) ;		// copy constructor
                    mkMatrix( int nRows, int nCols) ;		// constructs an empty matrix of this size
                    mkMatrix(int size, bool set_diagonal = true) ;	// creates a square matrix
                    //mkMatrix(VARIANT& var) ;				// from a SAFEARRAY variant
    virtual			~mkMatrix();							// destructor
//	void			Serialize(CArchive& archive) ;		// serialization
    void SetData(int r, int c, double * pData);
    void SetColVector( double * pData);
    void GetColVector( double * pData);
    // matrix mathematical operations
    mkMatrix&		operator=(const mkMatrix &other) ;
    mkMatrix			operator+(const mkMatrix &other) const ;
    mkMatrix			operator-(const mkMatrix &other) const ;
    mkMatrix			operator*(const mkMatrix &other) const ;
    void			operator+=(const mkMatrix &other) ;
    void			operator-=(const mkMatrix &other) ;
    void			operator*=(const mkMatrix &other) ;
    void			operator*=(double value) ;
    void			operator+=(double value) ;//MKIM
    void			operator-=(double value) ;//MKIM
    void			operator/=(double value) ;
    friend mkMatrix	operator*(const mkMatrix &other, double value) ;
    friend mkMatrix	operator/(const mkMatrix &other, double value) ;
    friend mkMatrix	operator+(const mkMatrix &other, double value) ;//MKIM
    friend mkMatrix	operator-(const mkMatrix &other, double value) ;//MKIM
    bool			operator==(const mkMatrix &other) const ;
  //  const mkMatrixHelper	operator[](int nCol) const ;			// reading version
  //  mkMatrixHelper	operator[](int nCol) ;					// writing version

    // element access
    bool			SetElement(int nRow, int nCol,  double value) ;
#ifdef _DEBUG
    double			GetElement(int nRow, int nCol) const ;
#else
    inline double	GetElement(int nRow, int nCol) const { return m_pData[nCol + nRow * m_nCol] ; }
#endif
    inline int		GetNumColumns() const { return m_nCol ; }
    inline int		GetNumRows() const { return m_nRow ; }
    double			SumColumn(int col) const ;
    double          SumAll() const;
    double			SumRow(int row) const ;
    double			SumColumnSquared(int col) const ;
    double			SumRowSquared(int row) const ;
    double			GetRowMin(int row) const ;
    int             GetRowMinIndex(int row) const;
    int             GetRowMaxIndex(int row) const;
    int             GetAbsMinIndex() const;
    double			GetRowMax(int row) const ;
    double			GetColumnMin(int col) const ;
    int             GetColumnMinIndex(int column) const;
    int             GetColumnMaxIndex(int column) const;
    double			GetColumnMax(int col) const ;
    // matrix transposition
    mkMatrix			GetTransposed() const ;
    void			Transpose() ;
    // matrix inversion
    mkMatrix			GetInverted() const ;
    mkMatrix			Invert() ;
    // covariant (A' * A)
    mkMatrix			Covariant() const ;
    // normalisation
    mkMatrix			GetNormalised(double min, double max) const ;
    void			Normalise(double min, double max) ;
    // ranges functions
    void			GetNumericRange(double &min, double &max) const ;
    // matrix concatenation
    mkMatrix			GetConcatinatedColumns(const mkMatrix& other) const ;
    void			ConcatinateColumns(const mkMatrix &other) ;
    mkMatrix			GetConcatinatedRows(const mkMatrix& other) const ;
    void			ConcatinateRows(const mkMatrix &other) ;
    // adds an new row / column to the matrix
    void			AddColumn(const double *pData) ;
    void			AddRow(const double *pData) ;
    // sub matrix extraction, setting
    mkMatrix			ExtractSubMatrix(int row_start, int col_start, int col_size, int row_size) const ;
    void			SetSubMatrix( int row_start,int col_start, const mkMatrix &other) ;
    mkMatrix			ExtractDiagonal() const ;
    // squaring the matrix functions
    mkMatrix			GetSquareMatrix() const ;
    void			MakeSquare() ;
    // export functions/import
//	VARIANT			GetSafeArray() const ;
    void			CopyToClipboard() const ;
    void			WriteAsCSVFile(const char* filename) const ;
    static mkMatrix	ReadFromCSVFile(const char* filename) ;

    // virtual functions
#ifdef _DEBUG
//	virtual void	Dump(CDumpContext& dc) const ;
    //virtual void	_ASSERTValid() const ;
#endif

public:
    ///////////////////////////////////////////////////////////////////////////
    // ++ MKIM
   // int GetRowMaxIndex(int row) const;
    void SetOriginalSize();
    void Resize(int nr, int nc);
    int getMaxLen();
    double Trace();
    mkMatrix Mean();
    void SetElements(int sRow,int sCol, const mkMatrix &In);
    mkMatrix GetElements(int sRow,int nRow, int sCol, int nCol) const;
    void Reset(double val);
    void Zeros(int rw, int cw);
    void Diag(int size, double * vec);
    void Eye(int size);
    void Eye(int size, double val);
    void SetEye(double val);
    mkMatrix Inverse();
    mkMatrix getRow(int index);
    mkMatrix getCol(int index);
    // -- MKIM
    //////////////////////////////////////////////////////////////////////////////

private:
    // private internal functions
    int m_nRow_original, m_nCol_original;
    double*			AllocateMemory(int nROws, int nCols) ;
    double**		Make2Dim(double *pData,int nRows, int nCols);
    // reference counting functions
    void			IncrementReferenceCount() ;	// increments the m_pData reference count
    void			DecrementReferenceCount() ;	// decrements the m_pData reference count
    void			DecrementAndRelease() ;		// decrements the count and releases the memory if required
    int				GetReferenceCount() const ;	// returns the m_pData's reference count
    // helper functions
    char *			GetRowAsText(int row) const ;
//	static CString	ReadLine(CXFile &file) ;		// reads a \r\n delimited line of text from a file
 //   static int		GetStringToken(CString source, CString &destination, int start, char ch) ;
};

//////////////////////////////////////////////////////////////////
typedef struct strCalData{
    mkMatrix LM;
    mkMatrix lm[6];
    mkMatrix numLM;
    /////////////////////////
    mkMatrix numPicks;
    mkMatrix Picked;
    mkMatrix PickedM;
}TypeCalData;

//void Norm(mkMatrix &mat, mkMatrix &out, int n=1);
//mkMatrix Norm(mkMatrix &mat, int m2=1);
void fprintMat(char *name, mkMatrix &mat);
double Norm(const mkMatrix &mat, int m2=1);
void Normalize(double mat[]);
void Matching(const mkMatrix &Cp,const mkMatrix &Tp, mkMatrix &Out);
void printMat(const char *name, mkMatrix &mat);
mkMatrix getCenterTriangle( mkMatrix &orderTri,  mkMatrix &LM,  mkMatrix &numPick);
mkMatrix Cross(const mkMatrix &A, const mkMatrix &B) ;
void Cross(double A[], double B[], double C[]) ;
double Dot(const mkMatrix &A,const mkMatrix &B);

mkMatrix removeRedundantPoint(mkMatrix LM);
double mkRMS(mkMatrix &data, mkMatrix &iPick, int length);
void getMinPoints(const double min_dis_ref, const mkMatrix &Cp, const mkMatrix &Tp,  mkMatrix &matchedPoint);
void main_cal_mkICP();
mkMatrix getIndexPicked(mkMatrix &numPick);
double diffclock(clock_t clock1,clock_t clock2);
////////////////////////////////////////////////////////////
// Calculate eigen value and vectors...
void eig(mkMatrix &In, mkMatrix &eig_Value, mkMatrix &eig_Vector);
void tred2(double **a, int n, double d[], double e[]);
void tqli(double d[], double e[], int n, double **z) ;
/////////////////////////////////////////////////////////////
void euler_axis_angle(const mkMatrix &R,const mkMatrix &u, double &phi);
void euler_axis_to_rotation_matrix(const mkMatrix &e,  double phi, mkMatrix &R);
bool rot2euler(mkMatrix &in_rot, double out_euler3[], bool isRad=1);
mkMatrix traXYZ(double x, double y, double z);
// 4x4 Homogeneous matrix
mkMatrix rotX(double deg);
mkMatrix rotY(double deg);
mkMatrix rotZ(double deg);

mkMatrix rotXrad(double rad);
mkMatrix rotYrad(double rad);
mkMatrix rotZrad(double rad);

// 3x3 rotational matrix
mkMatrix rotX3(double rad);
mkMatrix rotY3(double rad);
mkMatrix rotZ3(double rad);

// 3x3 scew matrix
mkMatrix tild(double v0, double v1, double v2);
mkMatrix tild(double v[]);
double sign(double a);
#endif // MKMATRIX_H
