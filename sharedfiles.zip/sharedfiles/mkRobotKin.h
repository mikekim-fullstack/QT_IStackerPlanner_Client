#ifndef MKROBOTKIN_H
#define MKROBOTKIN_H
//#include "mkGlobalData.h"
#include "../sharedfiles/mkmatrix.h"
#include <iostream>
#include "mkglobalclass.h"
using namespace std;
const double TOL=  (1.0e-10);
const double TOL1=  (1.0e-8);
const double EPSILON (1.0e-5);
//extern globalSharedData gSharedData;
#ifndef NUMJNT
#define NUMJNT 4
#endif
class MKZoeRobotKin
{
public:
    typedef struct
    {
        double th1, th2; // joint angle
        double Px,Py, Pz;      // x,y,z(Elevation) position of robot

        double EEx, EEy,EEz;  // x,y, z position of End-Effector
        double EEth; // tip angle of End-Effector

    } KIN_PARAM;
    // Cubical Polynominal coefficients for joint angle trajectory
    double aCo[NUMJNT][4];// [row: joint number][ col: a0, a1, a2, a3]

    // Cubical Polynominal coefficients for End-Effector trajectory
    double aCoEE[NUMJNT][4];// [row: EEx, EEy, EEth, EEz][ col: a0, a1, a2, a3]
    ///////////////////////////////////////////////////////////////////
    // Physical Parameters of Robot and Station
    const double minJntLimit[NUMJNT] =    {   0,    0,    -122.256,     -145.283};// X,Z,R1,R2
    const double maxJntLimit[NUMJNT] =    {1650, 1000,    228.252-122.256,  290.654-145.283};// X,Z,R1,R2
    const double minTargetLimit[NUMJNT] = {   0, -465,      0, -180};// TargetX, TargetY, TargetZ, TargetAng
    const double maxTargetLimit[NUMJNT] = {1650,  465, 1000.0,  180};// TargetX, TargetY, TargetZ, TargetAng
    const double X_UPPERLIMIT = 1650.0;// Travel Length Limit: Left-Right[mm]
    const double Z_UPPERLIMIT = 1000.0;// Travel Length Limit: Up-Down [mm]
    const double R1_LIMIT[2] = { -95*DTOR, 106*DTOR};// Radian
    const double R2_LIMIT[2] = {-153*DTOR, 150*DTOR};// Radian
    const double offDisX_MovingColumn = 110.0;// From origin 0 to the center of moving column in X dir.
    const double offDisX = 255.131;   // From 0 to the center of hinge R1  in X dir. [mm]
    const double offDisY = -19.0389;  // From 0 to the center of cupHolder in Y dir. [mm]
    const double offDisZ = 694.086;   // From 0 to the center of cupHolder in Z dir. [mm]
    const double Link1 = 215;         // Link1 length[mm] - from R1 to R2
    const double Link2 = 250;         // Link2 length[mm] - from R2 to the center of cup hoder

    //////////////////////////////////////////////////////////////
    const double cupHeight = 140;     // [mm]
    const double cupBottomH = 96.5;   //from center of cup holder to the bottom of cup[mm]
    const double counterTopH = 688.34;//[mm]=27"
    const double safeZoneY[2]={-175, 130};   // Arm-Link2 can swing at area from -175 to 130 in Y dir
    const double safeZoneZ = cupBottomH*cupHeight; // Arm-Link2 can swing above "safeZoneZ " in Z dir
    //////////////////////////////////////////////////////////////
    double Lr=Link1/Link2;
    KIN_PARAM param;// 3-Joints  including Lx motion
    KIN_PARAM bkParam;
    double curX=0, curY=0, curZ=0, curR1=0, curR2=0;
    double curAxisValue[7]={0};
    double curEEx=00, curEEy=0, curEEth=0;
    //double currentJointPos[4]={0};
    mkMatrix T0[NUMJNT];
    enum ELBOW_CONFIG {ELBOW_DOWN=-1, ELBOW_ON, ELBOW_UP   };

public:
    MKZoeRobotKin()
    {
        for(int i=0; i<4; i++) T0[i].Eye(4);
        forKin(0,0,0,0);
    }
    MKZoeRobotKin( const MKZoeRobotKin &other)
    {
        //        memcpy(&param, &other.param, sizeof(KIN_PARAM));
        //        memcpy(&bkParam, &other.bkParam, sizeof(KIN_PARAM));
        param = other.param;
        bkParam = other.bkParam;
        memcpy(curAxisValue, other.curAxisValue, sizeof(double)*7);
        curX = other.curX;
        curY = other.curY;
        curZ = other.curZ;
        curEEx = other.curEEx;
        curEEy = other.curEEy;
        curEEth = other.curEEth;
        for(int i=0; i<4; i++) T0[i]=other.T0[i];

    }
    ~MKZoeRobotKin()
    {

    }
    MKZoeRobotKin & operator=(const MKZoeRobotKin &other)
    {
        //        cout<<"assigned="<<endl;
        if(&other==this) return *this;
        memcpy(&param, &other.param, sizeof(KIN_PARAM));
        memcpy(&bkParam, &other.bkParam, sizeof(KIN_PARAM));
        memcpy(curAxisValue, other.curAxisValue, sizeof(double)*7);
        curX = other.curX;
        curY = other.curY;
        curZ = other.curZ;
        curEEx = other.curEEx;
        curEEy = other.curEEy;
        curEEth = other.curEEth;
        for(int i=0; i<4; i++) T0[i]=other.T0[i];
        return *this;
    }
    void setElevation(double moveZ)
    {
        param.Pz = moveZ;
        param.EEz =  moveZ;
    }
    bool arcMotionIK(double arcR, double cenPos[2], double EndEffectorAng, double rotAng)
    {
        double EEx = cenPos[0] + arcR * cos(rotAng);
        double EEy = cenPos[1] + arcR * sin(rotAng);
        double EEth = EndEffectorAng;

        return invKinEE_W_XYR(EEx, EEy, EEth);
    }
    int checkJointLimit()
    {
        //cout<<"Px="<<param.Px<<", Pz="<<param.Pz<<", Th1="<<param.th1<<", Th2="<<param.th2<<endl;
        int jnt=0;
        if(param.Px <minJntLimit[0] || param.Px>maxJntLimit[0]) { jnt =1; goto GOTO_JOINT_LIMIT_ERROR;}
        if(param.Pz <minJntLimit[1] || param.Pz>maxJntLimit[1]) { jnt =2; goto GOTO_JOINT_LIMIT_ERROR;}

        if(param.th1 <(minJntLimit[2]*DTOR - 0.0009)|| param.th1>maxJntLimit[2]*DTOR) { jnt =3; goto GOTO_JOINT_LIMIT_ERROR;}
        if(param.th2 <(minJntLimit[3]*DTOR - 0.0009) || param.th2>maxJntLimit[3]*DTOR) { jnt =4; goto GOTO_JOINT_LIMIT_ERROR;}

        return 0;

        GOTO_JOINT_LIMIT_ERROR:
        cout<< "-------> joint limit error:"<<jnt<<endl;
        return jnt;
    }
    int checkJointLimit(double px, double r1, double r2, double pz)
    {   // R1, R2 is in [degree] input
       // cout<<"Px="<<param.Px<<", Pz="<<param.Pz<<", Th1="<<param.th1<<", Th2="<<param.th2<<endl;
        int jnt=0;
        if(px <minJntLimit[0] || px>maxJntLimit[0]) { jnt =0; goto GOTO_JOINT_LIMIT_ERROR;}
        if(pz <minJntLimit[1] || pz>maxJntLimit[1]) { jnt =1; goto GOTO_JOINT_LIMIT_ERROR;}

        if(r1 <(minJntLimit[2]-0.05) || r1>maxJntLimit[2]) { jnt =2; goto GOTO_JOINT_LIMIT_ERROR;}
        if(r2 <(minJntLimit[3]-0.05) || r2>maxJntLimit[3]) { jnt =3; goto GOTO_JOINT_LIMIT_ERROR;}

        return 0;

        GOTO_JOINT_LIMIT_ERROR:
        cout<< "-------> joint limit error:"<<jnt<<endl;
        return jnt;

    }
    void forKin()
    {
        forKin(curX, curZ, curR1, curR2);
    }
    void forKin(double *val)
    {
        forKin(val[0], val[1],val[2],val[3]);
    }
    void forKin(double moveX, double moveZ, double th1, double th2)
    {
        // Check Joint Limit
        if(moveX<=0.0) moveX=0;
        else if(moveX>=X_UPPERLIMIT) moveX=X_UPPERLIMIT;

        if(moveZ<=0.0) moveZ=0;
        else if(moveZ>=Z_UPPERLIMIT) moveZ=Z_UPPERLIMIT;

        mkMatrix T12, T23;
        double cth1 = cos(th1);
        double sth1 = sin(th1);
        double cth2 = cos(th2);
        double sth2 = sin(th2);

        param.Px = moveX;
        param.Pz = moveZ ;
        param.th1 =th1;
        param.th2 =th2;

        double dT12[16] ={cth1, -sth1, 0, Link1*cth1,
                          sth1,  cth1, 0, Link1*sth1,
                          0, 0, 1, 0,
                          0, 0, 0, 1};
        double dT23[16] ={cth2, -sth2, 0, Link2*cth2,
                          sth2,  cth2, 0, Link2*sth2,
                          0, 0, 1, 0,
                          0, 0, 0, 1};
        T12.SetData(4,4, dT12);
        T23.SetData(4,4, dT23);

        T0[0]= traXYZ(moveX,0,0);//R1
        T0[1] = T0[0]*T12;//R2
        T0[2] = T0[1]*T23;//EE


        param.Pz = moveZ ;
        param.EEz = moveZ ;
        param.EEx = T0[2].m_ppData[0][3]; //moveXlen + Link2 * cos(th1 + th2) + Link1 * cth1;
        param.Py=param.EEy = T0[2].m_ppData[1][3];//Link2 * sin(th1 + th2) + Link1 * sth1;
        param.EEth = th1 + th2;

        updateForJointCtrlDlg();

    }
    void forKinDelta(double delta_moveX,double delt_moveZ, double delta_th1, double delta_th2)
    {
        forKin(param.Px+delta_moveX, param.Pz+delt_moveZ, param.th1+delta_th1, param.th2+delta_th2);
    }

    bool invKin_W_XYRZ(double eeX, double eeY, double eeTheta, double eeElevation=0)
    {//_W_: World Frame
        param.Pz = eeElevation;
        return invKinEE_W_XYR(eeX, eeY, eeTheta);
    }
    bool invKinEE_L2W_XYR(double lEEx, double lEEy, double lEEth)
    { //_L_: Local Frame
        // Transform local EE coordinate to World frame
        mkMatrix W_EE = rotZrad(lEEth)*traXYZ(lEEx, lEEy,0);
        double EEx = W_EE.m_ppData[0][3];
        double EEy = W_EE.m_ppData[1][3];
        double EEth = lEEth;

        // cout<<"Local --- EEx: "<<lEEx<<", EEy: "<<lEEy<<", EEth: "<< lEEth*RTOD<<", param.EEth: "<<  param.EEth*RTOD<<endl;
        // printMat("W_EE", W_EE);

        //% Case1: Lx Moving
        double b = (EEy - Link2 * sin(EEth)) / (Link1);
        if (abs(b) > 1.0)
            return false;
        param.EEx = EEx;
        param.EEy = EEy;
        param.EEth= EEth;

        param.th1 = asin(b);
        param.th2 = EEth - param.th1;
        param.Px = EEx - (Link2 * cos(EEth) + Link1 * cos(param.th1));

        if(param.Px<minJntLimit[0] || param.Px>maxJntLimit[0]) return false;

        forKin(param.Px, param.Pz,param.th1, param.th2);
        return true;
    }
    bool invKinEE_L2W_XYRZ(double lEEx, double lEEy, double lEEth, double EEz)
    {
        param.Pz = param.EEz = EEz;
        return invKinEE_L2W_XYR( lEEx,  lEEy,  lEEth);
    }
    bool invKinEE_L2W_XYRZ(double EE[])
    {
        if(!EE) return false;
        return invKinEE_L2W_XYRZ(EE[0], EE[1], EE[3], EE[2]);
    }
    bool invKinEE_L2W_XYR_Delta(double delEEx, double delEEy, double delEEth)
    {//_L_: LOCAL cartesian Frame
        mkMatrix L_EE = rotZrad(-param.EEth)*traXYZ(param.EEx, param.EEy,0);
        // cout<<"World --- EEx: "<<param.EEx<<", EEy: "<<param.EEy<<", EEth: "<< param.EEth*RTOD<<endl;
        // printMat("L_EE", L_EE);
        double lEEx = L_EE.m_ppData[0][3]   + delEEx;
        double lEEy = L_EE.m_ppData[1][3]   + delEEy;
        double lEEth = param.EEth + delEEth;


        return invKinEE_L2W_XYR( lEEx,  lEEy,  lEEth);
    }
    bool invKinEE_L_XYRZ_Delta(double delEE[])
    {
        if(!delEE) return false;
        return invKinEE_L_XYRZ_Delta(delEE[0], delEE[1], delEE[3], delEE[2]);
    }
    bool invKinEE_L_XYRZ_Delta(double delEEx, double delEEy, double delEEth, double delEEz)
    {
        param.EEz +=delEEz;
        param.Pz = param.EEz;
        return invKinEE_L2W_XYR_Delta(delEEx, delEEy, delEEth);
    }
    bool invKinEE_W_XYR(double EEx, double EEy, double EEth)
    { //_W_: World Frame

        //% Case1: Lx Moving
        double b = (EEy - Link2 * sin(EEth)) / (Link1);
        if (abs(b) > 1.0) {
            cout<<"------ IK: No Solution--------\n";
            return false;
        }
        param.EEx = EEx;
        param.EEy = EEy;
        param.EEth= EEth;

        param.th1 = asin(b);
        param.th2 = EEth - param.th1;
        param.Px = EEx - (Link2 * cos(EEth) + Link1 * cos(param.th1));

        if(param.Px<minJntLimit[0] || param.Px>maxJntLimit[0]) return false;

       // forKin(param.Px, param.Pz,param.th1, param.th2);
        if( checkJointLimit() == 0) return true;
        return false;
    }
    bool invKinEE_W_XYRZ(double EEx, double EEy, double EEth, double EEz)
    {
        param.EEz =EEz;
        param.Pz = param.EEz;
        return  invKinEE_W_XYR(EEx, EEy, EEth);
    }
    bool invKinEE_W_XYR_Delta(double delEEx, double delEEy, double delEEth)
    {//_W_: World Frame

        //% Case1: Lx Moving
        double EEx = param.EEx   + delEEx;
        double EEy = param.EEy   + delEEy;
        double EEth = param.EEth + delEEth;

        return invKinEE_W_XYR( EEx,  EEy,  EEth);
    }

    bool invKinEE_W_XY(double EEx, double EEy)
    {//_W_: World Frame
        //% Case2: Lx not moving
        double a=(EEx-(param.Px+Link2*cos(param.EEth)))/Link1;
        if (abs(a) > 1.0)
            return false;

        double Jt1=-acos(a);
        double Jt2 = (param.EEth-Jt1);

        double T03d[16] = {
            cos(Jt1 + Jt2), -sin(Jt1 + Jt2), 0,    param.Px + Link2*cos(Jt1 + Jt2) + Link1*cos(Jt1),
            sin(Jt1 + Jt2),  cos(Jt1 + Jt2), 0,                  Link2*sin(Jt1 + Jt2) + Link1*sin(Jt1),
            0,             0, 1,                                0,
            0,             0, 0,     1};
        mkMatrix T03(4,4, T03d);
        //% check sign of Jt1
        if(sqrt(pow(T03.m_ppData[0][3]-EEx,2)+pow(T03.m_ppData[1][3]-EEy,2))>1e-6) {
            Jt1 = -acos(a);
            Jt2 = (param.EEth-Jt1);
        }

        param.EEx = EEx;
        param.Py = param.EEy = EEy;
        param.th1 = Jt1;
        param.th2 = Jt2;

        return true;
    }
    bool invKinEE_W_R(double EEth)
    {//_W_: World Frame
        //% Case1: Lx Moving
        double b = (param.EEy - Link2 * sin(EEth)) / (Link1);
        if (abs(b) > 1.0)
            return false;
        param.EEth= EEth;

        param.th1 = asin(b);
        param.th2 = EEth - param.th1;
        param.Px = param.EEx - (Link2 * cos(EEth) + Link1 * cos(param.th1));

        forKin(param.Px, param.Pz,param.th1, param.th2);

        return true;
    }

    bool invKinMoveX(double moveX, double EEx, double EEy)
    { // EEx, EEy fixed, but  th1, th2 and EEth should be calcuted...

        double a=EEy/Link2;
        double b=(EEx-moveX)/Link2;
        double c=( a*a + b*b + Lr*Lr - 1.0)/(2.0*Lr);
        const double aa=a*a, bb=b*b;
        double M=asin(c/sqrt(aa+bb));
        double N=acos(a/sqrt(aa+bb));
        double t1_1=M-N;
        double t1_2=M+N;
        double t1=0;
        if(abs(a*sin(t1_1)+b*cos(t1_1)-c)<0.00001) {
            t1=t1_1;
        }
        else if(abs(a*sin(t1_2)+b*cos(t1_2)-c)<0.00001){
            t1=t1_2;
        }
        else{
            return false;//disp 'No solution'
        }
        int elbowConfig = getElbowConfig();
        t1 = t1*elbowConfig;
        param.EEx = EEx;
        param.EEy = EEy;

        double t12 = acos((param.EEx-moveX-Link1*cos(t1))/Link2)*elbowConfig;
        double t2=t12-t1;

        param.Px=moveX;
        //        if(abs(t1)>M_PI)
        //        {
        //            double s =sign(t1);
        //            if(s>0.0)
        //        }
        param.th1=t1;
        param.th2=t2;

        forKin(param.Px, param.Pz, param.th1, param.th2);
        return true;
    }




    int getElbowConfig()
    {
        /////////////////////////////////////////////////////

        // Check if arm config is elbow up or elbow down
        // Pos(x1, y1) is the JR3 on Link1
        double x1 = T0[0].m_ppData[0][3]+offDisX;
        double y1 = T0[0].m_ppData[1][3]+offDisY;

        // Pos(x2, y2) is the EE on the center of cup
        double x2 = T0[2].m_ppData[0][3]+offDisX;
        double y2 = T0[2].m_ppData[1][3]+offDisY;

        // Pos(x, y) is the JR2 on the Link2
        double x = T0[1].m_ppData[0][3]+offDisX;
        double y = T0[1].m_ppData[1][3]+offDisY;

        double p1[3]={x1,y1,0};
        double p2[3]={x2,y2,0};
        double p[3]={x,y,0};
        mkMatrix P1(1,3,p1);
        mkMatrix P2(1,3,p2);
        mkMatrix P(1,3,p);
        mkMatrix V1 = P2-P1;
        mkMatrix V2 = P - P1;

        mkMatrix V = Cross(V1,V2);
        double elbow = V.m_pData[2];
        //        double v1[2] = {x2-x1, y2-y1} ;  //# Vector 1
        //        double v2[2] = {x-x1, x-y1} ; // # Vector 1
        //        double elbow =v1[0]*v2[1] - v1[1]*v2[0];//  # Cross product
        cout<<"elbow config: "<<elbow<<": P1= ["<<x1<<", "<<y1<< ",0];, P2= ["<<x2<<", "<<y2<< ",0];, P= ["<<x<<", "<<y<<",0];"<<endl;
        if(elbow>=0) return ELBOW_UP;
        else  return ELBOW_DOWN;
        // else return ELBOW_ON;
    }
    bool invKinMoveX(double moveX)
    { // EEx, EEy fixed, but  th1, th2 and EEth should be calcuted...
        double a=param.EEy/Link2;
        double b=(param.EEx-moveX)/Link2;
        double c=( a*a + b*b + Lr*Lr - 1.0)/(2.0*Lr);
        double d_2 = a*a + b*b -c*c;
        if(d_2<0) return false;
        double d=sqrt(d_2);


        double t1=0, t2=0;
        double t1_1 = atan2(a*c+b*d,b*c-a*d);
        double t1_2 = atan2(a*c-b*d,b*c+a*d);

        double delT1_1 = abs(t1_1-param.th1);
        double delT1_2 = abs(t1_2-param.th1);

        if(delT1_1<=delT1_2)
            t1 = t1_1;
        else
            t1 = t1_2;
        //... Find the angle #2 closed to previous th2...
        double t12 = acos((param.EEx-moveX-Link1*cos(t1))/Link2);
        double t2a[3];
        t2a[0] =  t12 - t1;
        t2a[1] = -t12 - t1;
        t2a[2] = asin((param.EEy-Link1*sin(t1))/Link2)-t1;

        MKZoeRobotKin testRobotKin(*this);
        for(int i=0; i<3; i++)
        {
            testRobotKin.forKin(moveX,param.Pz,t1,t2a[i]);
            double eex = param.EEx-testRobotKin.param.EEx;
            double eey = param.EEy-testRobotKin.param.EEy;
            if(sqrt(eex*eex + eey*eey)<1.e-5)
            {
                param.Px=moveX;
                param.th1=t1;
                param.th2=t2;
                *this = testRobotKin;
                return true;
            }
        }
        updateForJointCtrlDlg();
        return false;
    }


    double getColumnXPos()
    {
        return (param.Px-offDisX);
    }
    void printForKin()
    {
        cout<<"ForwardKin=> ColumnXPos:"<<getColumnXPos()<<", Joint: X[mm]="<<param.Px<<", Y[mm]="<<param.Py<<", Z[mm]="<<param.Pz<<",R1[DEG]="<<param.th1*180.0/M_PI<<", R2[DEG]="<<param.th2*180.0/M_PI<<endl;
        cout<<"InverseKin(x,y,z,th)=> "<<param.EEx+offDisX<<", "<<param.EEy+offDisY<<", "<<param.EEz+offDisZ<<", "<<param.EEth<<", "<<param.Py<<endl;
    }
    void printInvKin()
    {
        cout<<"InverseKin(x,y,z,th): "<<param.EEx<<", "<<param.EEy<<", "<<param.EEz<<", "<<param.EEth<<", "<<param.Py<<endl;
    }
    void setFinalJointByMouseUp()
    {
        // Length: mm, Angle[rad]

        if(param.th1<=R1_LIMIT[0]) param.th1=R1_LIMIT[0];
        else if(param.th1>=R1_LIMIT[1]) param.th1=R1_LIMIT[1];

        if(param.th2<=R2_LIMIT[0]) param.th2=R2_LIMIT[0];
        else if(param.th2>=R2_LIMIT[1]) param.th2=R2_LIMIT[1];

        curX=param.Px;
        curY=param.Py=param.EEy;
        curZ=param.Pz;
        curR1=param.th1;
        curR2=param.th2;

        curEEx= param.EEx;
        curEEy= param.EEy;
        curEEth= param.EEth;
        forKin();
        // cout<<"===== setFinalJointByMouseUp =========="<<endl;
    }
    void updateCurrentJoint()
    {
        // Length: mm, Angle[Rad]
        curX=param.Px;
        curY=param.Py=param.EEy;
        curZ=param.Pz;
        curR1=param.th1;
        curR2=param.th2;

        curEEx= param.EEx;
        curEEy= param.EEy;
        curEEth= param.EEth;

        forKin();

        // cout<<"===== setFinalJointByMouseUp =========="<<endl;
    }
    void updateForJointCtrlDlg()
    {
        curAxisValue[0]=param.Px;
        curAxisValue[1]=param.Pz;
        curAxisValue[2]=param.th1;
        curAxisValue[3]=param.th2;
        curAxisValue[4]=param.EEx;
        curAxisValue[5]=param.EEy;
        curAxisValue[6]=param.EEth;
    }
    void getJointPos(double *pos)
    {
        if(!pos) return;
        pos[0]=param.Px;
        pos[1]=param.Pz;
        pos[2]=param.th1;
        pos[3]=param.th2;
    }
    void getWEEPos(double *pos)
    {
        if(!pos) return;
        pos[0]=param.EEx;
        pos[1]=param.EEy;
        pos[2]=param.EEz=param.Pz;
        pos[3]=param.EEth;

    }
    void getLEEPos(double *pos)
    {
        //////////////////////////////
        // Local Cartesian Frame...
        //
        if(!pos) return;
        mkMatrix L_EE = rotZrad(-param.EEth)*traXYZ(param.EEx, param.EEy,0);
        // cout<<"World --- EEx: "<<param.EEx<<", EEy: "<<param.EEy<<", EEth: "<< param.EEth*RTOD<<endl;
        // printMat("L_EE", L_EE);
        double lEEx = L_EE.m_ppData[0][3]  ;
        double lEEy = L_EE.m_ppData[1][3]   ;

        pos[0]=lEEx;
        pos[1]=lEEy;
        pos[2]=param.EEz=param.Pz;
        pos[3]=param.EEth;

    }
    int setCubicalPolynominalJointInter( double Tf, double *initialJointPos, double *finalJointPos)
    {
        if(Tf<=TOL) return -1;
        bool isSameTrajectory=true;
        for(int i=0; i<NUMJNT; i++) {
            aCo[i][0] = initialJointPos[i];
            aCo[i][1] = 0.0;
            aCo[i][2] = 3.0*(finalJointPos[i]-initialJointPos[i])/(Tf*Tf);
            aCo[i][3] = -2.0*(finalJointPos[i]-initialJointPos[i])/(Tf*Tf*Tf);
            if(abs(aCo[i][2])>TOL) {
                isSameTrajectory=false;
            }
        }
        if(isSameTrajectory==true) return 0;
        return 1;
    }
    int setCubicalPolynominalEEInter( double Tf, double *initialEEPos, double *finalEEPos)
    {
        if(Tf<=TOL) return -1;
        bool isSameTrajectory=true;
        for(int i=0; i<NUMJNT; i++) {
            aCoEE[i][0] = initialEEPos[i];
            aCoEE[i][1] = 0.0;
            aCoEE[i][2] = 3.0*(finalEEPos[i]-initialEEPos[i])/(Tf*Tf);
            aCoEE[i][3] = -2.0*(finalEEPos[i]-initialEEPos[i])/(Tf*Tf*Tf);
            if(abs(aCoEE[i][2])>TOL) {
                isSameTrajectory=false;
            }
        }
        if(isSameTrajectory==true) return 0;
        return 1;
    }

    double calCubicPolynomial(double T, double Tf, double Qi, double Qf)
    {
        if(Tf<=TOL) return -1;

        double aCoe[4];

        aCoe[0] = Qi;
        aCoe[1] = 0.0;
        aCoe[2] = 3.0*(Qf-Qi)/(Tf*Tf);
        aCoe[3] = -2.0*(Qf-Qi)/(Tf*Tf*Tf);
        return (aCoe[0]+aCoe[1]*T+aCoe[2]*T*T+aCoe[3]*T*T*T);
    }
    // **************** genSpeedProfile() ********************//
    // ...OUTPUT...
    // steps: total steps(pluse)
    // Na : pulse counts for acceleration area
    // Nac : pulse counts for acceleration and constant areas
    // NNb : pulse counts for deceleration area
    // Cn_acc0: fisrt period time for 1st pulse of acceleration on Timer.
    // dir: direction
    void genSpeedProfile(RobotProperty & robotStatus, PacketSpeed &targetSpeed, PacketSpeedProfile& outSpeedProfile, uint16_t cmdCode=SC_SET_SPEED)
    {
        double distance = targetSpeed.diffPos;
        double speed =  targetSpeed.vel*(2.0*M_PI/robotStatus.LEADPITCH);
        double accel = targetSpeed.accel*(2.0*M_PI/robotStatus.LEADPITCH);
        double decel = accel;
        if(robotStatus.jointType==JT_ROT)
        {
            //////////////////////////////
            // COVERT ALL UINT FROM DEGREE TO RADIAN
            //distance *= M_PI/180.0;
            speed *= M_PI/180.0;
            accel *= M_PI/180.0;
            decel *= M_PI/180.0;
        }


        if(distance<0){
            distance*=-1.0;
            outSpeedProfile.dir = -1;
        }
        else {
            outSpeedProfile.dir = 1;

        }

        outSpeedProfile.cmdCode = cmdCode;
        outSpeedProfile.axisID = targetSpeed.axisID;
        outSpeedProfile.jobID = targetSpeed.jobID;
        outSpeedProfile.nSequence = targetSpeed.nSequence;

        // If JT_ROT, input [Deg] otherwist input[mm] and output is steps [pulse]
        double steps = lround(robotStatus.getStepsFromDistance(distance));// PULLY & BELT TYPE (20 TEETH, 5MM PITCH)
        //  unsigned long steps = DIST2STEP_20TH2*distance;
        double  alpha = robotStatus.getAlpha();//  % [rad] angle per step
        double two_alpha = 2.0*alpha ;// alpha*2
        double Ttotal=0;

        // % 1. Calculate Time
        // % Ta = speed/acceleration
        double Ta = speed/accel; //%[sec]
        double Tb = speed/decel; //%[sec]
        double Tc = (steps*alpha - 0.5*accel*Ta*Ta - 0.5*decel*Tb*Tb)/speed;
        if(Tc>0)
        {
            Ttotal = Ta+Tc+Tb;
        }
        else
        {
            Ttotal = Ta+Tb;
        }


        // % 2. Calculate Step
        // % convert Time Zone to Stepper Motor Count
        // % Acceleration Zone
        // % n = speed^2/(2*alpha*accel)
        uint32_t Nb, Nc;
        outSpeedProfile.steps = floor(steps);

        outSpeedProfile.Na = floor(speed*speed/(two_alpha*accel));
        uint32_t Nacc = floor(steps*decel/(accel+decel));


        if(outSpeedProfile.Na<Nacc){
            //%Nb = floor(speed^2/(2*alpha*decel));
            Nb = floor(accel/decel*outSpeedProfile.Na);
            Nc = outSpeedProfile.steps - (outSpeedProfile.Na+Nb);
        }
        else{
            outSpeedProfile.Na = Nacc;
            Nb = outSpeedProfile.steps - Nacc;
            Nc = 0;
        }
        outSpeedProfile.Nac = outSpeedProfile.Na + Nc;
        outSpeedProfile.NNb = Nb;
        outSpeedProfile.Cn_acc0 = uint32_t(TICK_FREQ_SQRT_ERROR_COM * sqrt(two_alpha / accel));
        outSpeedProfile.Cn_dec0 = uint32_t(TICK_FREQ_SQRT_ERROR_COM * sqrt(two_alpha / decel));
        outSpeedProfile.rest = (TICK_FREQ_SQRT_ERROR_COM * sqrt(two_alpha / accel) - outSpeedProfile.Cn_acc0);

//        int Cn_const_speed = int(TICK_FREQ_SQRT_ERROR_COM*sqrt(two_alpha/accel)*(sqrt(outSpeedProfile.Na+1)-sqrt(outSpeedProfile.Na)));
//        int Cn_dec0 = int(TICK_FREQ_SQRT_ERROR_COM*sqrt(two_alpha/decel));

        outSpeedProfile.pack();
        //cout<<"genSpeedProfile()=> Total Time:"<< Ttotal<<", Alpha=:"<< alpha<<", Steps:"<<steps<<", Na:"<<outSpeedProfile.Na<<endl;
    }
    /////////////////////////////////////////////////////////////////
    // * EETheta [rad]
    //* //
#if 0
    int gen_Line_profile( double EEx[2], double EEy[2], double EETheta, double speed)
    {
      ///////////////////////////////////
      double dx=abs(EEx[1]-EEx[0]);
      double dy=-abs(EEy[1]-EEy[0]);

      double sx = (EEx[0]<EEx[1]) ? 1 : -1;
      double sy = (EEy[0]<EEy[1]) ? 1 : -1;
      double err = dx+dy;
      int x = round(EEx[0]);
      int y = round(EEy[0]);
      double dist = sqrt(dx*dx + dy*dy);
    ////////////////////////////////////////////////////////
      // ++ deltaT_Lx is duration when EE rotate 1deg ++
      double DIST2STEP[4]={16.0, 2291.83*2, 763.944*4.0,80.0}; //[X, R1, R2, Z]
      double STEP2DIST[4]={1.0/DIST2STEP[0], 1.0/DIST2STEP[1], 1.0/DIST2STEP[2], 1.0/DIST2STEP[3]}; //[X, R1, R2, Z]

      // int8_t rotDir = SIGN(circleProfile.arcAng);
      double deltaPos[3]={0}, residue[3]={0}, prevResidue[3]={0};
      double deltaPos_residue[3]={0};
      double prevPos[3]={0}, steps[3]={0};
      double abs_sum_steps[3]={0};
      double totalDistance[3]={0};
      //double dist[nAng+1] ;
      int cnt_zeros[3]={0};
      int index_step[3]={0};

      // double deltaT_per_1deg = 1.0/circleProfile.speed;
      double abs_step[3]={0};
      double abs_step_1[3]={0},abs_step_residue [3]={0};
      int acc_area = round(dist*0.1); // accelleration area from start (x%)
      int acc_dec_area = acc_area;
      double deltaT = 1.0/speed;
      // int acc_area[3] = {10};
      bool bCheckSum=true;
      // bool bDebug=0;
      double sum_deltaPos[3]={0}, sum_stepPos[3]={0};
      double diffSteps=0;

    /////////////////////////////////////////////////////////////////////////
    // Calculation for index 0
      int i=0;
      if(!invKin(x, y, EETheta))
      {
        //if(bDebug) printf("!!!! NO IK SOLUTION !!!!\n");
        return ERROR+1;
      }
       prevPos[0] = kinParam.L;// Calculated by arcMotionIK (initial deltaPosue)
       prevPos[1] = kinParam.t1;
       prevPos[2] = kinParam.t2;
      //////////////////////////////////////////////////////////////////////
      // -- Start to calcute the number of pulses, delay time counts (Cn) and direction of motors

      while(1)
      {
        if (x == EEx[1] && y == EEy[1]) break;
        //-------------------------------------------------------//
        //////////////////////////////////////////////////////////
        // Calculate the I.K.
        if(!invKin(x, y, EETheta))
        {
          // if(bDebug) printf("!!!! NO IK SOLUTION !!!!\n");
          return ERROR+2;
        }
        ////////////////////////////////////////////////
        // Handing 3 motors...
        for(int CH=0; CH<3; CH++)
        {
          //////////////////////////////////////////////////
        // Handling Acceleration and Deceleration by adding more time
        if(i<acc_dec_area)                              deltaT = exp(double(acc_area)*1.5/double(acc_dec_area));
        else if(i> (dist-acc_dec_area)) deltaT = exp(double(acc_area)*1.5/double(acc_dec_area));
        else                                            deltaT = 1.0;
          /////////////////////////////////////////
          // Calculate Delta Position
          // 0: X - Linear Motion (mm)
          if(CH==0) {
            deltaPos[CH] = (kinParam.L - prevPos[CH]); // [mm]
            totalDistance[CH] += abs(deltaPos[CH]);
            prevPos[CH] = kinParam.L;
          }
          /////////////////////////////////////////
          // 1: R1 - Rotation Motion (rad)
          else if(CH==1) {
            deltaPos[CH] = (kinParam.t1 - prevPos[CH]); // [mm]
            totalDistance[CH] += abs(deltaPos[CH]);
            prevPos[CH] = kinParam.t1;

          }
          /////////////////////////////////////////
          // 2: R2 - Rotation Motion (rad)
          else if(CH==2) {
            deltaPos[CH] = (kinParam.t2 - prevPos[CH]); // [mm]
            totalDistance[CH] += abs(deltaPos[CH]);
            prevPos[CH] = kinParam.t2;
          }
          // "sum_deltaPos[CH]"" is for checking if there is difference between real step count and calculate count...
          sum_deltaPos[CH] += deltaPos[CH];
        //%---------------------------------------------------------------------//
        //% Only accept more than one step if not, calculate the residue and pass
        //% it to next step...
          if(i==0) {
              deltaPos_residue[CH] =  deltaPos[CH];
          } else {
              deltaPos_residue[CH] =  deltaPos[CH] + prevResidue[CH]; // Add Residue
          }

          abs_step[CH] = abs(DIST2STEP[CH]*deltaPos_residue[CH]);
          if(abs_step[CH]>=1.0) {
            abs_step_1[CH] = round(abs_step[CH]);
            abs_step_residue[CH] = abs_step[CH] - abs_step_1[CH];
            steps[CH] = SIGN(deltaPos[CH])*abs_step_1[CH];
            residue[CH] = SIGN(deltaPos[CH]) * abs_step_residue[CH] * STEP2DIST[CH];
          }
          else {
            steps[CH]=0;
            residue[CH] =deltaPos_residue[CH];
          }
          prevResidue[CH] = residue[CH];
          abs_sum_steps[CH] += abs(steps[CH]);

          // prevResidue = SIGN(deltaPos) * (incPos - abs_sum_steps[CH]*STEP2DIST[CH]);

          ///////////////////////////////////////////////

          // if(bDebug) printf("---- step[%d] --- %f, abs_step=%f, val=%f\n",i,steps[CH],abs_step[CH], deltaPos_residue[CH]);

          //--------------------------------------------------------------------//
          // Based on number of steps, calcuate Cn(count for delay) and direction
          // of motor and number of steps for this duration...

          if (steps[CH] == 0) {
            cnt_zeros[CH]++;
          }
          else
          {
            if(cnt_zeros[CH]>0){
              kinData[CH].motionData[index_step[CH]].Cn = round(tick_freq * deltaT * cnt_zeros[CH] / abs(steps[CH]));
              // if(bDebug) printf(" -------- zeros[%d], cnt_zeros=%d, Cn=%d\n", index_step[CH], cnt_zeros[CH], motionData[CH][index_step[CH]].Cn);
              cnt_zeros[CH]=0;
            } else {
                kinData[CH].motionData[index_step[CH]].Cn = round(tick_freq * deltaT / abs(steps[CH]));

            }
            kinData[CH].motionData[index_step[CH]].steps = abs((steps[CH]));
            kinData[CH].motionData[index_step[CH]].dir = SIGN(deltaPos[CH]); // stepper motor direction...
            // "sum_stepPos[CH]"" is for checking if there is difference between real step count and calculate count...
            sum_stepPos[CH] += double(kinData[CH].motionData[index_step[CH]].steps)*double(kinData[CH].motionData[index_step[CH]].dir);

            index_step[CH]++;

          }

          //%----------------------------------------------------------------------
          //% Since the motor direction is not changing right time due to the
          //% numerical error, we need to correct it...
          //% if diffSteps is larger than 0.5, compensate it by adding one more step
          //% with correcting the direction of motor...
          // !!!!! NOT WORKING HERE!!!!!
          // if(index_step[CH]>0) {
          //    diffSteps = sum_deltaPos[CH]*DIST2STEP[CH]- sum_stepPos[CH];
          //    if(abs(round(diffSteps))>=1.0) {
          //       motionData[CH][index_step[CH]].Cn = tick_freq * deltaT / abs(round(diffSteps));
          //       if(diffSteps>0) motionData[CH][index_step[CH]].dir =  1;
          //       else            motionData[CH][index_step[CH]].dir = -1;
          //       index_step[CH]++;
          //    }

          // }


          //%-----------------------------------------------------------------------------
          //% Lastly check if there is unfinised pulse, if so add one more pulse
          //% with previous direction...
          if(int(dist-1)==i) {
            kinData[CH].totalSteps = int32_t(round(totalDistance[CH] * DIST2STEP[CH]));
            if(cnt_zeros[CH]>0)
            {
              kinData[CH].motionData[index_step[CH]].Cn = round(tick_freq * deltaT * (cnt_zeros[CH])) ;
              kinData[CH].motionData[index_step[CH]].steps=1;
              kinData[CH].motionData[index_step[CH]].dir = kinData[CH].motionData[index_step[CH]-1].dir; // stepper motor direction...
              abs_sum_steps[CH] += 1;
              steps[CH] = kinData[CH].totalSteps - (abs_sum_steps[CH]);
              if(steps[CH]>0){
                kinData[CH].motionData[index_step[CH]].Cn = round(tick_freq * deltaT * cnt_zeros[CH] / abs(steps[CH])) ;
                kinData[CH].motionData[index_step[CH]].steps=abs(steps[CH]);
                kinData[CH].motionData[index_step[CH]].dir = kinData[CH].motionData[index_step[CH]-1].dir; // stepper motor direction...
              }
              abs_sum_steps[CH] += abs(steps[CH]);

              //if(bDebug) printf("last--- Cn[%d]: %d, %d,  cnt_zeros=%d\n", index_step[CH], motionData[CH][index_step[CH]].steps, motionData[CH][index_step[CH]].Cn,   cnt_zeros[CH]); //[mm]
              index_step[CH]++;
            }
            else {
              steps[CH] = kinData[CH].totalSteps - abs_sum_steps[CH];
              if(steps[CH]>0){
                kinData[CH].motionData[index_step[CH]].Cn = round(tick_freq * deltaT/ abs(steps[CH])) ;
                kinData[CH].motionData[index_step[CH]].steps=abs(steps[CH]);
                kinData[CH].motionData[index_step[CH]].dir = kinData[CH].motionData[index_step[CH]-1].dir; // stepper motor direction...
                abs_sum_steps[CH] += abs(steps[CH]);
                index_step[CH]++;
              }
            }// ----------else
             kinData[CH].dataSize = index_step[CH];
            //  kinData[CH].dataSize =  uint16_t(abs(circleProfile.cenPosY));//test
            //  kinData[CH].totalSteps = unsigned long( abs_sum_steps[CH]);//test
            if(kinData[CH].totalSteps!=abs_sum_steps[CH]) bCheckSum=false;
            // if(bDebug) printf( "totalsteps=%d, abs_sum_steps=%d,  diff(totalSteps-abs_sum_steps)=%f, motionDataSize=%d\n",
            //                 totalSteps[CH], int(abs_sum_steps[CH]), totalSteps[CH]-abs_sum_steps[CH], motionDataSize[CH]);

            // if(bDebug) printf("-- Joint ID = %d::result ----------------- totalDistance=%4.3f, totalsteps=%d\n\n\n\n", CH, totalDistance[CH], totalSteps[CH]);

          }// --------  if((nAng-1)==i) {
          /*
          if((nAng-1)==i) {
            totalSteps[CH] = round(totalDistance[CH] * DIST2STEP[CH]);
            if(cnt_zeros[CH]>0)
            {
              motionData[CH][index_step[CH]].Cn = tick_freq * deltaT * (cnt_zeros[CH]) ;
              motionData[CH][index_step[CH]].steps=1;
              motionData[CH][index_step[CH]].dir = motionData[CH][index_step[CH]-1].dir; // stepper motor direction...
              abs_sum_steps[CH] += 1;

              // if(bDebug) printf("last--- Cn[%d]: %d, %d,  cnt_zeros=%d\n", index_step[CH], motionData[CH][index_step[CH]].steps, motionData[CH][index_step[CH]].Cn,   cnt_zeros[CH]); //[mm]
              index_step[CH]++;
            }
              motionDataSize[CH] = index_step[CH];
              double diffSteps = sum_deltaPos[CH]*DIST2STEP[CH]- sum_stepPos[CH];
              if(abs(diffSteps)>0.001) bCheckSum=false;
              // if(bDebug) printf( "diffSteps=%2.3f, totalsteps=%d, abs_sum_steps=%d,  diff(totalSteps-abs_sum_steps)=%f, motionDataSize=%d\n",
              //                 diffSteps, totalSteps[CH], int(abs_sum_steps[CH]), totalSteps[CH]-abs_sum_steps[CH], motionDataSize[CH]);

              // if(bDebug) printf("-- Joint ID = %d::result ----------------- totalDistance=%4.3f, totalsteps=%d\n\n\n\n", CH, totalDistance[CH], totalSteps[CH]);
          }// --------  if((nAng-1)==i) {
          */
        }// --------- for(CH)
        if(i<acc_dec_area)                              acc_area--;
        else if(i> (dist-acc_dec_area)) acc_area++;
        else                                            acc_area=2;

        /////////////////////////////////////////////////////
        double e2 = 2*err;
          if (e2 >= dy) {
              err = err + dy;
              x = x + sx;
              }
          else if (e2 <= dx) {
              err = err + dx;
              y = y + sy;
          }
           ++i;
      }
      if(bCheckSum){
        return 1;
      }// Calculation is right
      else {
         return ERROR+3;
      }// total steps and sum of step is different (Calculation is wrong)...
    }
#endif
};

#endif // MKROBOTKIN_H
